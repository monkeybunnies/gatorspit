/*
 * ServerViewBid.java
 *
 * Created on April 11, 2005, 2:26 AM
 */

/**
 *
 * @author  Andi
 */
import java.util.*;
import java.util.HashMap;

public class ServerViewBid extends Thread implements Runnable{
    private BidDataStructure bid;
    //private SellDataStructure sell;
    private String trID;
    private String CID;
    private String serverName;
    private RMI rmi;
    /** Creates a new instance of ServerViewBid */
    public ServerViewBid(String trID, BidDataStructure bid, String CID, String serverName, RMI rmi) {
        //sell = new SellDataStructure();
        this.bid = bid;
        this.trID = trID;
        this.CID = CID;
        this.serverName = serverName;
        this.rmi = rmi;
    }
    
    public void run() {
        ClientInterface c = rmi.getMyClient(CID+"_on_"+serverName);
        Hashtable<String, HashMap> getBid = new Hashtable<String, HashMap>();
        getBid.putAll((HashMap)bid.viewBidList(trID));
        if (!getBid.isEmpty()) {
            for (Enumeration e = getBid.keys() ; e.hasMoreElements() ;) {
                String key = (String) e.nextElement();
                try {
                    c.printMessage("Bidder ID: "+getBid.get(key).get("BidderID")+"   Bid Value: $"+getBid.get(key).get("Value")+"   Bid Time: "+getBid.get(key).get("Bid Time"));
                } catch (Exception er) {System.out.println(er);}
            }
            if (bid.MeetReservePrice(trID))
                try {
                    c.printMessage("Meet Reserve Price?   YES");
                } catch (Exception er) {System.out.println(er);}
            else
                try {
                    c.printMessage("Meet Reserve Price?   NO");
                } catch (Exception er) {System.out.println(er);}
        }
        else
            try {
                c.printMessage("No bid in the bid list yet.");
            } catch (Exception er) {System.out.println(er);}
    }
}
