/*
 * ServerViewItem.java
 *
 * Created on April 11, 2005, 1:20 AM
 */

/**
 *
 * @author  Andi
 */
import java.util.*;
import java.util.HashMap;

public class ServerViewItem extends Thread implements Runnable {
    private SellDataStructure sell;
    private String CID;
    private String serverName;
    private RMI rmi;
    private BidDataStructure bidList;

    /** Creates a new instance of ServerViewItem */
    public ServerViewItem(SellDataStructure sell, BidDataStructure bidlist,String CID, String serverName, RMI rmi) {
        this.sell = sell;
        this.bidList=bidlist;
        this.CID = CID;
        this.serverName = serverName;
        this.rmi = rmi;
    }
    public void run() {
        
        ClientInterface c = rmi.getMyClient(CID+"_on_"+serverName);
        /*
        Hashtable<String, HashMap> getItem = new Hashtable<String, HashMap>();
        getItem.putAll((HashMap)sell.viewSellList());
        if (!getItem.isEmpty()) {
            for (Enumeration e = getItem.keys() ; e.hasMoreElements() ;) {
                String key = (String) e.nextElement();
                try {
                    c.printMessage("Transaction ID: "+key+"   Item Name: "+getItem.get(key).get("Name")+"   Amount: "+getItem.get(key).get("Amount"));
                    c.printMessage("Description: "+getItem.get(key).get("Description"));
                    c.printMessage("Closing Time: "+getItem.get(key).get("Closing Time")+"   Starting Price: "+getItem.get(key).get("Starting Price")+"   Present Highest Bid: "+sell.getHighestBid(key));
                    c.printMessage("Seller ID: "+getItem.get(key).get("Seller ID")+"   Status: "+getItem.get(key).get("Status"));
                    c.printMessage("------------------------------------Refresh in 4 seconds--------------------------------------------------");
                } catch(Exception er) {System.out.println(er);}
            }
        }
        else
            try {
                c.printMessage("No item in the sell list yet.");
            } catch(Exception er) {System.out.println(er);}
         **/
        GameOver gameover=new GameOver(sell,bidList);
        HashMap<String,HashMap> showList=new HashMap<String,HashMap>();
        showList=gameover.gameOver();
        HashMap<String,HashMap> openList=new HashMap<String,HashMap>();
        HashMap<String,HashMap> olist=new HashMap<String,HashMap>();
        HashMap<String,String> copylist=new HashMap<String,String>();
        //HashMap<String,String> listContent=new HashMap<String,String>();
        Iterator iterator = showList.keySet().iterator();
        int i=0;
       //HashMap<String,HashMap> itemList=sell.viewSellList();
        if(iterator.hasNext()){
       while (iterator.hasNext()) {
	   String key = (String)iterator.next();
           String flag=key.substring(0,1);
           String itemKey=key.substring(2);
           HashMap<String,String> listContent=new HashMap<String,String>();
           
           listContent=showList.get(key);
           
           //System.out.println("Item's "+itemKey+"flag is:"+flag);
            //Iterator it = itemList.keySet().iterator();
            /*if(!it.hasNext()) System.out.println("No item");
            while(it.hasNext()){
                String ilist=(String)it.next();
                System.out.println("key is:"+ilist);
            }
           */     
           if(flag.equals("O")){
               openList.put(Integer.toString(i),listContent);
               copylist.put(itemKey, listContent.get("Closing time"));
               olist.put(itemKey,listContent);
               i++;
                
           }
         
          
       
       }
        Double[] closetime=new Double[i];
        
        for(int j=0;j<i;j++){
            HashMap<String,String> l=new HashMap<String,String>();
            l=openList.get(Integer.toString(j));
            closetime[j]=sell.changeTimeFormat(l.get("Closing time"));
        }
          
        double ctime=0.0;
        //String[] cltime=new String[i];
        int k;
        for(k=i;k>0;k--){
            for(int m=0;m<k;m++){
               if(closetime[m+1]<closetime[m])
                    ctime=closetime[m];
                    closetime[m]=closetime[m+1];
                    closetime[m+1]=ctime;
            }
            
        }
        Iterator iterat = copylist.keySet().iterator();
        String[] keylist=new String[i];
        int m=0;
        String[] showShow=new String[i];
         HashMap<String,String> slist=new HashMap<String,String>();
        while (iterat.hasNext()) 
	   keylist[i] = (String)iterator.next();
        for(k=0;k<i;k++){
            String cltime=Double.toString(closetime[k]);
            for(m=0;m<i;m++){
               if(cltime==copylist.get(keylist[m]))
                 break;
            }
            slist=olist.get(keylist[m]);
            showShow[k]="ItemID:"+keylist[m]+",Item Name:"+slist.get("Item Name")+",Description:"+slist.get("Description")+",Highest Bid Price:"+slist.get("Highest Bid Price")+",Bidder ID:"+slist.get("Bidder ID")+",Seller ID:"+slist.get("Seller ID")+",Reach Reserve Price:"+slist.get("Reach Reserve Price")+",Closing Time:"+slist.get("Closing time");
            try {
                c.printMessage(showShow[k]);
            }catch (Exception e) {System.out.println(e);}
        }
            
                
        //
        
      }
        else System.out.println("Empty list!");
    }
    
    
    
}      

