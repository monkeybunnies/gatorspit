/*
 * Inventory.java
 *
 * Created on March 27, 2005, 11:31 PM
 */

/**
 *
 * @author  Shuo
 */
import java.util.*;
import java.util.Hashtable;

public class Inventory {
    
    /** Creates a new instance of Inventory */
    public Inventory() {
        
    }
    
    
    /**Randomly allocate some goods to a
     *new user to play the game.
     */
    public Hashtable GetMyGoods() {
        //option 1: 5 bl of CaramelPop: $5/bl
        //4 bl of AssortedChocolates: $5/bl
        //10 bl of Cashews: $2/bl
        //5 bl of VanillaButtercreams: $7/bl
        Hashtable deposit = new Hashtable<String, String>();
        deposit.put("money", "100");

        Hashtable CaramelPop1 = new Hashtable<String, String>();
        CaramelPop1.put("name", "CaramelPop");
        CaramelPop1.put("unitPrice", "5");
        CaramelPop1.put("amount", "5");
        
        Hashtable AssortedChocolates1 = new Hashtable<String, String>();
        AssortedChocolates1.put("name", "AssortedChocolates");
        AssortedChocolates1.put("unitPrice", "5");
        AssortedChocolates1.put("amount", "4");
        
        Hashtable Cashews1 = new Hashtable<String, String>();
        Cashews1.put("name", "Cashews");
        Cashews1.put("unitPrice", "2");
        Cashews1.put("amount", "10");
        
        Hashtable VanillaButtercreams1 = new Hashtable<String, String>();
        VanillaButtercreams1.put("name", "VanillaButtercreams");
        VanillaButtercreams1.put("unitPrice", "7");
        VanillaButtercreams1.put("amount", "5");
        
        Hashtable HersheysKisses1 = new Hashtable<String, String>();
        HersheysKisses1.put("name", "HersheysKisses");
        HersheysKisses1.put("unitPrice", "8");
        HersheysKisses1.put("amount", "0");
       
        Hashtable KitKatBar1 = new Hashtable<String, String>();
        KitKatBar1.put("name", "KitKatBar");
        KitKatBar1.put("unitPrice", "4");
        KitKatBar1.put("amount", "0");
        
        Hashtable TootsieRolls1 = new Hashtable<String, String>();
        TootsieRolls1.put("name", "TootsieRolls");
        TootsieRolls1.put("unitPrice", "5");
        TootsieRolls1.put("amount", "0");
        
        Hashtable JordanAlmonds1 = new Hashtable<String, String>();
        JordanAlmonds1.put("name", "JordanAlmonds");
        JordanAlmonds1.put("unitPrice", "10");
        JordanAlmonds1.put("amount", "0");
        
        Hashtable AnimalCrackers1 = new Hashtable<String, String>();
        AnimalCrackers1.put("name", "AnimalCrackers");
        AnimalCrackers1.put("unitPrice", "3");
        AnimalCrackers1.put("amount", "0");

        Hashtable CappuccinoChocolate1 = new Hashtable<String, String>();
        CappuccinoChocolate1.put("name", "CappuccinoChocolate");
        CappuccinoChocolate1.put("unitPrice", "10");
        CappuccinoChocolate1.put("amount", "0");
        
        Hashtable inventory1 = new Hashtable<String, Hashtable>();
        inventory1.put("Deposit", (Hashtable) deposit);
        inventory1.put("CaramelPop", (Hashtable) CaramelPop1);
        inventory1.put("AssortedChocolates", (Hashtable) AssortedChocolates1);
        inventory1.put("Cashews", (Hashtable) Cashews1);
        inventory1.put("VanillaButtercreams", (Hashtable) VanillaButtercreams1);
        inventory1.put("HersheysKisses", (Hashtable) HersheysKisses1);
        inventory1.put("KitKatBar", (Hashtable) KitKatBar1);
        inventory1.put("TootsieRolls", (Hashtable) TootsieRolls1);
        inventory1.put("JordanAlmonds", (Hashtable) JordanAlmonds1);
        inventory1.put("AnimalCrackers", (Hashtable) AnimalCrackers1);
        inventory1.put("CappuccinoChocolate", (Hashtable) CappuccinoChocolate1);
        
        //Option 2: 10 HersheysKisses: $3/bag
        //10 AnimalCrackers 1$/bl
        //20 KitKatBar: &1/bar
        //4  Cashews:  $5/bl
        //10 TootsieRolls: $2/bag
        Hashtable CaramelPop2 = new Hashtable<String, String>();
        CaramelPop2.put("name", "CaramelPop");
        CaramelPop2.put("unitPrice", "7");
        CaramelPop2.put("amount", "0");
        
        Hashtable AssortedChocolates2 = new Hashtable<String, String>();
        AssortedChocolates2.put("name", "AssortedChocolates");
        AssortedChocolates2.put("unitPrice", "10");
        AssortedChocolates2.put("amount", "0");
        
        Hashtable Cashews2 = new Hashtable<String, String>();
        Cashews2.put("name", "Cashews");
        Cashews2.put("unitPrice", "5");
        Cashews2.put("amount", "4");
        
        Hashtable VanillaButtercreams2 = new Hashtable<String, String>();
        VanillaButtercreams2.put("name", "VanillaButtercreams");
        VanillaButtercreams2.put("unitPrice", "8");
        VanillaButtercreams2.put("amount", "0");
        
        Hashtable HersheysKisses2 = new Hashtable<String, String>();
        HersheysKisses2.put("name", "HersheysKisses");
        HersheysKisses2.put("unitPrice", "3");
        HersheysKisses2.put("amount", "10");
       
        Hashtable KitKatBar2 = new Hashtable<String, String>();
        KitKatBar2.put("name", "KitKatBar");
        KitKatBar2.put("unitPrice", "1");
        KitKatBar2.put("amount", "20");
        
        Hashtable TootsieRolls2 = new Hashtable<String, String>();
        TootsieRolls2.put("name", "TootsieRolls");
        TootsieRolls2.put("unitPrice", "2");
        TootsieRolls2.put("amount", "10");
        
        Hashtable JordanAlmonds2 = new Hashtable<String, String>();
        JordanAlmonds2.put("name", "JordanAlmonds");
        JordanAlmonds2.put("unitPrice", "10");
        JordanAlmonds2.put("amount", "0");
        
        Hashtable AnimalCrackers2 = new Hashtable<String, String>();
        AnimalCrackers2.put("name", "AnimalCrackers");
        AnimalCrackers2.put("unitPrice", "1");
        AnimalCrackers2.put("amount", "10");

        Hashtable CappuccinoChocolate2 = new Hashtable<String, String>();
        CappuccinoChocolate2.put("name", "CappuccinoChocolate");
        CappuccinoChocolate2.put("unitPrice", "15");
        CappuccinoChocolate2.put("amount", "0");
        
        Hashtable inventory2 = new Hashtable<String, Hashtable>();
        inventory2.put("Deposit", (Hashtable) deposit);
        inventory2.put("CaramelPop", (Hashtable) CaramelPop2);
        inventory2.put("AssortedChocolates", (Hashtable) AssortedChocolates2);
        inventory2.put("Cashews", (Hashtable) Cashews2);
        inventory2.put("VanillaButtercreams", (Hashtable) VanillaButtercreams2);
        inventory2.put("HersheysKisses", (Hashtable) HersheysKisses2);
        inventory2.put("KitKatBar", (Hashtable) KitKatBar2);
        inventory2.put("TootsieRolls", (Hashtable) TootsieRolls2);
        inventory2.put("JordanAlmonds", (Hashtable) JordanAlmonds2);
        inventory2.put("AnimalCrackers", (Hashtable) AnimalCrackers2);
        inventory2.put("CappuccinoChocolate", (Hashtable) CappuccinoChocolate2);
        
        //option 3: 10 KitKatBar $1/bag
        //5 bls AssortedChocolates $10/bl
        //5 bls JordanAlmonds $5/bl
        //3 bls  AnimalCrackers $5/bl
        Hashtable CaramelPop3 = new Hashtable<String, String>();
        CaramelPop3.put("name", "CaramelPop");
        CaramelPop3.put("unitPrice", "10");
        CaramelPop3.put("amount", "0");
        
        Hashtable AssortedChocolates3 = new Hashtable<String, String>();
        AssortedChocolates3.put("name", "AssortedChocolates");
        AssortedChocolates3.put("unitPrice", "10");
        AssortedChocolates3.put("amount", "5");
        
        Hashtable Cashews3 = new Hashtable<String, String>();
        Cashews3.put("name", "Cashews");
        Cashews3.put("unitPrice", "10");
        Cashews3.put("amount", "0");
        
        Hashtable VanillaButtercreams3 = new Hashtable<String, String>();
        VanillaButtercreams3.put("name", "VanillaButtercreams");
        VanillaButtercreams3.put("unitPrice", "15");
        VanillaButtercreams3.put("amount", "0");
        
        Hashtable HersheysKisses3 = new Hashtable<String, String>();
        HersheysKisses3.put("name", "HersheysKisses");
        HersheysKisses3.put("unitPrice", "5");
        HersheysKisses3.put("amount", "0");
       
        Hashtable KitKatBar3 = new Hashtable<String, String>();
        KitKatBar3.put("name", "KitKatBar");
        KitKatBar3.put("unitPrice", "1");
        KitKatBar3.put("amount", "10");
        
        Hashtable TootsieRolls3 = new Hashtable<String, String>();
        TootsieRolls3.put("name", "TootsieRolls");
        TootsieRolls3.put("unitPrice", "7");
        TootsieRolls3.put("amount", "0");
        
        Hashtable JordanAlmonds3 = new Hashtable<String, String>();
        JordanAlmonds3.put("name", "JordanAlmonds");
        JordanAlmonds3.put("unitPrice", "5");
        JordanAlmonds3.put("amount", "5");
        
        Hashtable AnimalCrackers3 = new Hashtable<String, String>();
        AnimalCrackers3.put("name", "AnimalCrackers");
        AnimalCrackers3.put("unitPrice", "5");
        AnimalCrackers3.put("amount", "3");

        Hashtable CappuccinoChocolate3 = new Hashtable<String, String>();
        CappuccinoChocolate3.put("name", "CappuccinoChocolate");
        CappuccinoChocolate3.put("unitPrice", "7");
        CappuccinoChocolate3.put("amount", "0");
        
        Hashtable inventory3 = new Hashtable<String, Hashtable>();
        inventory3.put("Deposit", (Hashtable) deposit);
        inventory3.put("CaramelPop", (Hashtable) CaramelPop3);
        inventory3.put("AssortedChocolates", (Hashtable) AssortedChocolates3);
        inventory3.put("Cashews", (Hashtable) Cashews3);
        inventory3.put("VanillaButtercreams", (Hashtable) VanillaButtercreams3);
        inventory3.put("HersheysKisses", (Hashtable) HersheysKisses3);
        inventory3.put("KitKatBar", (Hashtable) KitKatBar3);
        inventory3.put("TootsieRolls", (Hashtable) TootsieRolls3);
        inventory3.put("JordanAlmonds", (Hashtable) JordanAlmonds3);
        inventory3.put("AnimalCrackers", (Hashtable) AnimalCrackers3);
        inventory3.put("CappuccinoChocolate", (Hashtable) CappuccinoChocolate3);
        
        //option 4: 4bls Cashews $5/bl
        //10 KitKatBar: $1/bar
        //5 JordanAlmonds: &6/bl
        //10 AnimalCrackers: $2/bag
        //2 CappucchinoChocolate: $10/bag
        Hashtable CaramelPop4 = new Hashtable<String, String>();
        CaramelPop4.put("name", "CaramelPop");
        CaramelPop4.put("unitPrice", "3");
        CaramelPop4.put("amount", "0");
        
        Hashtable AssortedChocolates4 = new Hashtable<String, String>();
        AssortedChocolates4.put("name", "AssortedChocolates");
        AssortedChocolates4.put("unitPrice", "6");
        AssortedChocolates4.put("amount", "0");
        
        Hashtable Cashews4 = new Hashtable<String, String>();
        Cashews4.put("name", "Cashews");
        Cashews4.put("unitPrice", "5");
        Cashews4.put("amount", "4");
        
        Hashtable VanillaButtercreams4 = new Hashtable<String, String>();
        VanillaButtercreams4.put("name", "VanillaButtercreams");
        VanillaButtercreams4.put("unitPrice", "9");
        VanillaButtercreams4.put("amount", "0");
        
        Hashtable HersheysKisses4 = new Hashtable<String, String>();
        HersheysKisses4.put("name", "HersheysKisses");
        HersheysKisses4.put("unitPrice", "6");
        HersheysKisses4.put("amount", "0");
       
        Hashtable KitKatBar4 = new Hashtable<String, String>();
        KitKatBar4.put("name", "KitKatBar");
        KitKatBar4.put("unitPrice", "1");
        KitKatBar4.put("amount", "10");
        
        Hashtable TootsieRolls4 = new Hashtable<String, String>();
        TootsieRolls4.put("name", "TootsieRolls");
        TootsieRolls4.put("unitPrice", "5");
        TootsieRolls4.put("amount", "0");
        
        Hashtable JordanAlmonds4 = new Hashtable<String, String>();
        JordanAlmonds4.put("name", "JordanAlmonds");
        JordanAlmonds4.put("unitPrice", "6");
        JordanAlmonds4.put("amount", "5");
        
        Hashtable AnimalCrackers4 = new Hashtable<String, String>();
        AnimalCrackers4.put("name", "AnimalCrackers");
        AnimalCrackers4.put("unitPrice", "2");
        AnimalCrackers4.put("amount", "10");

        Hashtable CappuccinoChocolate4 = new Hashtable<String, String>();
        CappuccinoChocolate4.put("name", "CappuccinoChocolate");
        CappuccinoChocolate4.put("unitPrice", "10");
        CappuccinoChocolate4.put("amount", "2");
        
        Hashtable inventory4 = new Hashtable<String, Hashtable>();
        inventory4.put("Deposit", (Hashtable) deposit);
        inventory4.put("CaramelPop", (Hashtable) CaramelPop4);
        inventory4.put("AssortedChocolates", (Hashtable) AssortedChocolates4);
        inventory4.put("Cashews", (Hashtable) Cashews4);
        inventory4.put("VanillaButtercreams", (Hashtable) VanillaButtercreams4);
        inventory4.put("HersheysKisses", (Hashtable) HersheysKisses4);
        inventory4.put("KitKatBar", (Hashtable) KitKatBar4);
        inventory4.put("TootsieRolls", (Hashtable) TootsieRolls4);
        inventory4.put("JordanAlmonds", (Hashtable) JordanAlmonds4);
        inventory4.put("AnimalCrackers", (Hashtable) AnimalCrackers4);
        inventory4.put("CappuccinoChocolate", (Hashtable) CappuccinoChocolate4);
        
        //option 5: 6 CaramelPop $5/bl
        //10 VanillaButtercreams $4/bl
        //10 bls JordanAlmonds $3/bl
        Hashtable CaramelPop5 = new Hashtable<String, String>();
        CaramelPop5.put("name", "CaramelPop");
        CaramelPop5.put("unitPrice", "5");
        CaramelPop5.put("amount", "6");
        
        Hashtable AssortedChocolates5 = new Hashtable<String, String>();
        AssortedChocolates5.put("name", "AssortedChocolates");
        AssortedChocolates5.put("unitPrice", "5");
        AssortedChocolates5.put("amount", "0");
        
        Hashtable Cashews5 = new Hashtable<String, String>();
        Cashews5.put("name", "Cashews");
        Cashews5.put("unitPrice", "6");
        Cashews5.put("amount", "0");
        
        Hashtable VanillaButtercreams5 = new Hashtable<String, String>();
        VanillaButtercreams5.put("name", "VanillaButtercreams");
        VanillaButtercreams5.put("unitPrice", "4");
        VanillaButtercreams5.put("amount", "10");
        
        Hashtable HersheysKisses5 = new Hashtable<String, String>();
        HersheysKisses5.put("name", "HersheysKisses");
        HersheysKisses5.put("unitPrice", "6");
        HersheysKisses5.put("amount", "0");
       
        Hashtable KitKatBar5 = new Hashtable<String, String>();
        KitKatBar5.put("name", "KitKatBar");
        KitKatBar5.put("unitPrice", "3");
        KitKatBar5.put("amount", "0");
        
        Hashtable TootsieRolls5 = new Hashtable<String, String>();
        TootsieRolls5.put("name", "TootsieRolls");
        TootsieRolls5.put("unitPrice", "5");
        TootsieRolls5.put("amount", "0");
        
        Hashtable JordanAlmonds5 = new Hashtable<String, String>();
        JordanAlmonds5.put("name", "JordanAlmonds");
        JordanAlmonds5.put("unitPrice", "3");
        JordanAlmonds5.put("amount", "10");
        
        Hashtable AnimalCrackers5 = new Hashtable<String, String>();
        AnimalCrackers5.put("name", "AnimalCrackers");
        AnimalCrackers5.put("unitPrice", "5");
        AnimalCrackers5.put("amount", "0");

        Hashtable CappuccinoChocolate5 = new Hashtable<String, String>();
        CappuccinoChocolate5.put("name", "CappuccinoChocolate");
        CappuccinoChocolate5.put("unitPrice", "8");
        CappuccinoChocolate5.put("amount", "0");
        
        Hashtable inventory5 = new Hashtable<String, Hashtable>();
        inventory5.put("Deposit", (Hashtable) deposit);
        inventory5.put("CaramelPop", (Hashtable) CaramelPop5);
        inventory5.put("AssortedChocolates", (Hashtable) AssortedChocolates5);
        inventory5.put("Cashews", (Hashtable) Cashews5);
        inventory5.put("VanillaButtercreams", (Hashtable) VanillaButtercreams5);
        inventory5.put("HersheysKisses", (Hashtable) HersheysKisses5);
        inventory5.put("KitKatBar", (Hashtable) KitKatBar5);
        inventory5.put("TootsieRolls", (Hashtable) TootsieRolls5);
        inventory5.put("JordanAlmonds", (Hashtable) JordanAlmonds5);
        inventory5.put("AnimalCrackers", (Hashtable) AnimalCrackers5);
        inventory5.put("CappuccinoChocolate", (Hashtable) CappuccinoChocolate5);
        
        //option 6: 5 bl CappuccinoChocolate $6/bl
        //10bls HersheysKisses: &3/bl
        //10 bg of KitKatBar: $2/bg
        //10 bl of TootsieRolls: $2/bl
        Hashtable CaramelPop6 = new Hashtable<String, String>();
        CaramelPop6.put("name", "CaramelPop");
        CaramelPop6.put("unitPrice", "10");
        CaramelPop6.put("amount", "0");
        
        Hashtable AssortedChocolates6 = new Hashtable<String, String>();
        AssortedChocolates6.put("name", "AssortedChocolates");
        AssortedChocolates6.put("unitPrice", "5");
        AssortedChocolates6.put("amount", "0");
        
        Hashtable Cashews6 = new Hashtable<String, String>();
        Cashews6.put("name", "Cashews");
        Cashews6.put("unitPrice", "7");
        Cashews6.put("amount", "0");
        
        Hashtable VanillaButtercreams6 = new Hashtable<String, String>();
        VanillaButtercreams6.put("name", "VanillaButtercreams");
        VanillaButtercreams6.put("unitPrice", "7");
        VanillaButtercreams6.put("amount", "0");
        
        Hashtable HersheysKisses6 = new Hashtable<String, String>();
        HersheysKisses6.put("name", "HersheysKisses");
        HersheysKisses6.put("unitPrice", "3");
        HersheysKisses6.put("amount", "10");
       
        Hashtable KitKatBar6 = new Hashtable<String, String>();
        KitKatBar6.put("name", "KitKatBar");
        KitKatBar6.put("unitPrice", "2");
        KitKatBar6.put("amount", "10");
        
        Hashtable TootsieRolls6 = new Hashtable<String, String>();
        TootsieRolls6.put("name", "TootsieRolls");
        TootsieRolls6.put("unitPrice", "2");
        TootsieRolls6.put("amount", "10");
        
        Hashtable JordanAlmonds6 = new Hashtable<String, String>();
        JordanAlmonds6.put("name", "JordanAlmonds");
        JordanAlmonds6.put("unitPrice", "10");
        JordanAlmonds6.put("amount", "0");
        
        Hashtable AnimalCrackers6 = new Hashtable<String, String>();
        AnimalCrackers6.put("name", "AnimalCrackers");
        AnimalCrackers6.put("unitPrice", "3");
        AnimalCrackers6.put("amount", "0");

        Hashtable CappuccinoChocolate6 = new Hashtable<String, String>();
        CappuccinoChocolate6.put("name", "CappuccinoChocolate");
        CappuccinoChocolate6.put("unitPrice", "6");
        CappuccinoChocolate6.put("amount", "5");
        
        Hashtable inventory6 = new Hashtable<String, Hashtable>();
        inventory6.put("Deposit", (Hashtable) deposit);
        inventory6.put("CaramelPop", (Hashtable) CaramelPop6);
        inventory6.put("AssortedChocolates", (Hashtable) AssortedChocolates6);
        inventory6.put("Cashews", (Hashtable) Cashews6);
        inventory6.put("VanillaButtercreams", (Hashtable) VanillaButtercreams6);
        inventory6.put("HersheysKisses", (Hashtable) HersheysKisses6);
        inventory6.put("KitKatBar", (Hashtable) KitKatBar6);
        inventory6.put("TootsieRolls", (Hashtable) TootsieRolls6);
        inventory6.put("JordanAlmonds", (Hashtable) JordanAlmonds6);
        inventory6.put("AnimalCrackers", (Hashtable) AnimalCrackers6);
        inventory6.put("CappuccinoChocolate", (Hashtable) CappuccinoChocolate6);
        
        Hashtable inventoryOptions = new Hashtable<String, Hashtable>();
        inventoryOptions.put("1", (Hashtable) inventory1);
        inventoryOptions.put("2", (Hashtable) inventory2);
        inventoryOptions.put("3", (Hashtable) inventory3);
        inventoryOptions.put("4", (Hashtable) inventory4);
        inventoryOptions.put("5", (Hashtable) inventory5);
        inventoryOptions.put("6", (Hashtable) inventory6);
        
        Random generator = new Random();
        int randomIndex = generator.nextInt(5) + 1;
        String index = Integer.toString(randomIndex);
        
        Hashtable goods = (Hashtable) inventoryOptions.get(index);
        return goods;
        //return index;
    }
    
}

