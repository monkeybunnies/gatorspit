

import java.util.*;
import java.util.HashMap;
import java.lang.*;
import java.util.concurrent.*;
/**
 *
 * @author Xin Fu
 */
public class GameOver {
    SellDataStructure Item;
    BidDataStructure BidValue;
    /** Creates a new instance of GameOver */
    public GameOver(SellDataStructure item, BidDataStructure bidvalue) {
        Item=item;
        BidValue=bidvalue;
    }
    /*public synchronized String[] gameOver(){
       HashMap<String,HashMap> itemList=Item.viewSellList();
      Iterator iterator = itemList.keySet().iterator();
       String[] itemID=new String[itemList.size()];
       HashMap<String,String> itemInfo;
       HashMap<String,HashMap> showList=new HashMap<String,HashMap>();
       String[] list=new String[itemList.size()];
       HashMap<String,String> bidnode=new HashMap<String,String>();
       //Hashmap<String,String> myBid=new HashMap<String,String>();
       double bidPrice=0.0;
       int i=0;
       Calendar cal = new GregorianCalendar();
        int hour24 = cal.get(Calendar.HOUR_OF_DAY);             // 0..59
        int minute = cal.get(Calendar.MINUTE);             // 0..59
        double bidTime = hour24 + .01*minute;
        String bTime = Double.toString(bidTime);
       while (iterator.hasNext()) {
	   itemID[i] = (String)iterator.next();
           itemInfo=itemList.get(itemID[i]);
           //System.out.println("itemID:"+itemID[i]);
           String resprice=itemInfo.get("Reserve Price");
           double icTime=Double.valueOf(itemInfo.get("Closing Time").trim()).doubleValue();
           HashMap<String,String> checkReserve=new HashMap<String,String>();
           //HashMap<String,String> AliveBid=new HashMap<String,String>();
           if(icTime>bidTime) {
               bidnode=BidValue.highestBid(itemID[i]);
               checkReserve.put("Item Name", itemInfo.get("Name"));
               checkReserve.put("Description", itemInfo.get("Description"));
               checkReserve.put("Highest Bid Price", bidnode.get("Value"));
               checkReserve.put("Bidder ID", bidnode.get("BidderID"));
               checkReserve.put("Seller ID",itemInfo.get("Seller ID"));
               showList.put("O "+itemID[i],checkReserve);
               list[i]="Open Item Name:"+checkReserve.get("Item Name")+",Highest Bid Price:"+checkReserve.get("Highest Bid Price")+",Bidder ID:"+checkReserve.get("Bidder ID")+",Seller ID:"+checkReserve.get("Seller ID");
           }
           else{ 
           
           if(!resprice.equals("")){
            double resPrice = Double.valueOf(resprice.trim()).doubleValue();
              // mybid[i]="BidderID:"+myBid.get("BidderID")+",Value:"+myBid.get("Value")+",Bid Time "+myBid.get("Bid Time");
            if(BidValue.checkTrID(itemID[i])){
              bidnode=BidValue.highestBid(itemID[i]);
              bidPrice=Double.valueOf(bidnode.get("Value").trim()).doubleValue();
              if(bidPrice<resPrice){
                  checkReserve.put("Item Name", itemInfo.get("Name"));
                  checkReserve.put("Description", itemInfo.get("Description"));
                  checkReserve.put("Sale Price", "Lower than Reserved Price");
                  checkReserve.put("Buyer ID", "");
                  checkReserve.put("Seller ID", "");
                  showList.put("C "+itemID[i],checkReserve);
              }
              else{
                  checkReserve.put("Item Name", itemInfo.get("Name"));
                  checkReserve.put("Description", itemInfo.get("Description"));
                  checkReserve.put("Sale Price", Double.toString(bidPrice));
                  checkReserve.put("Buyer ID", bidnode.get("BidderID"));
                  checkReserve.put("Seller ID",itemInfo.get("Seller ID"));
                  showList.put("C "+itemID[i],checkReserve);
              }
            }
           
           else{
                 checkReserve.put("Item Name", itemInfo.get("Name"));
                  checkReserve.put("Description", itemInfo.get("Description"));
                  checkReserve.put("Sale Price", "No Bider");
                  checkReserve.put("Buyer ID", "");
                  checkReserve.put("Seller ID", "");
                  showList.put("C "+itemID[i],checkReserve);
           }
                
           }
              else {
                  bidnode=BidValue.highestBid(itemInfo.get("Name"));
                  bidPrice=Double.valueOf(bidnode.get("Value").trim()).doubleValue();
                  checkReserve.put("Item Name", itemInfo.get("Name"));
                  checkReserve.put("Description", itemInfo.get("Description"));
                  checkReserve.put("Sale Price", Double.toString(bidPrice));
                  checkReserve.put("Buyer ID", bidnode.get("BidderID"));
                  checkReserve.put("Seller ID",itemInfo.get("Seller ID"));
                  showList.put("C "+itemID[i],checkReserve);
      
               }
               
               //System.out.println("item ended:"+list[i]);
               
               //BidValue.removeBidList(itemID[i]);
               list[i]="Closed Item Name:"+checkReserve.get("Item Name")+",Sale Price:"+checkReserve.get("Sale Price")+",Buyer ID:"+checkReserve.get("Buyer ID")+",Seller ID:"+checkReserve.get("Seller ID");
	    }

              i++;        
       }
               Item.clearList();
             
               BidValue.clearBidList();
     
       return(String[]) list;
    }
    */
    public HashMap<String,HashMap> gameOver(){
       HashMap<String,HashMap> itemList=Item.viewSellList();
      Iterator iterator = itemList.keySet().iterator();
       String[] itemID=new String[itemList.size()];
       HashMap<String,String> itemInfo;
       HashMap<String,HashMap> showList=new HashMap<String,HashMap>();
       String[] list=new String[itemList.size()];
       HashMap<String,String> bidnode=new HashMap<String,String>();
       //Hashmap<String,String> myBid=new HashMap<String,String>();
       double bidPrice=0.0;
       int i=0;
       
        Calendar cal = new GregorianCalendar();
        int hour24 = cal.get(Calendar.HOUR_OF_DAY);             // 0..59
        int min = cal.get(Calendar.MINUTE);             // 0..59
        int sec = cal.get(Calendar.SECOND);             // 0..59
        double bidTime = hour24*3600+60*min+sec;
       // System.out.println("Hello");
       while (iterator.hasNext()) {
	   itemID[i] = (String)iterator.next();
           itemInfo=itemList.get(itemID[i]);
           //System.out.println("itemID:"+itemID[i]);
           String resprice=itemInfo.get("Reserve Price");
           String closetime=itemInfo.get("Closing Time");
           //System.out.println("closing time:"+closetime);
           
           double icTime=Item.changeTimeFormat(closetime);
           HashMap<String,String> checkReserve=new HashMap<String,String>();
           //HashMap<String,String> AliveBid=new HashMap<String,String>();
           System.out.println(itemID[i]+"'s close Time:"+icTime+", current time:"+bidTime);
           if(icTime>bidTime) {
               System.out.println("still open!");
               double rPrice = Double.valueOf(resprice.trim()).doubleValue();
               if(BidValue.checkTrID(itemID[i]))
               {
               bidnode=BidValue.highestBid(itemID[i]);
               checkReserve.put("Item Name", itemInfo.get("Name"));
               checkReserve.put("Description", itemInfo.get("Description"));
               checkReserve.put("Highest Bid Price", bidnode.get("Value"));
               checkReserve.put("Bidder ID", bidnode.get("BidderID"));
               checkReserve.put("Seller ID",itemInfo.get("Seller ID"));
               
               if(rPrice>Double.valueOf(bidnode.get("Value").trim()).doubleValue()){
                 checkReserve.put("Reach Reserve Price","No");  
               }
               else checkReserve.put("Reach Reserve Price","Yes");
               checkReserve.put("Closing time",closetime);
               showList.put("O "+itemID[i],checkReserve);
               
               }
               else
               {
                  checkReserve.put("Item Name", itemInfo.get("Name"));
                  checkReserve.put("Description", itemInfo.get("Description"));
                  checkReserve.put("Highest Bid Price", "0");
                  checkReserve.put("Bidder ID", "");
                  checkReserve.put("Seller ID", itemInfo.get("Seller ID"));
                  checkReserve.put("Reach Reserve Price","No");  
                  checkReserve.put("Closing time",closetime);
                  showList.put("O "+itemID[i],checkReserve);
               }
                 list[i]="Open Item Name:"+checkReserve.get("Item Name")+",Highest Bid Price:"+checkReserve.get("Highest Bid Price")+",Bidder ID:"+checkReserve.get("Bidder ID")+",Seller ID:"+checkReserve.get("Seller ID");
           }
           else{ 
           
           if(!resprice.equals("")){
            double resPrice = Double.valueOf(resprice.trim()).doubleValue();
              // mybid[i]="BidderID:"+myBid.get("BidderID")+",Value:"+myBid.get("Value")+",Bid Time "+myBid.get("Bid Time");
            if(BidValue.checkTrID(itemID[i])){
              bidnode=BidValue.highestBid(itemID[i]);
              bidPrice=Double.valueOf(bidnode.get("Value").trim()).doubleValue();
              if(bidPrice<resPrice){
                  checkReserve.put("Item Name", itemInfo.get("Name"));
                  checkReserve.put("Description", itemInfo.get("Description"));
                  checkReserve.put("Sale Price", "Lower than Reserved Price");
                  checkReserve.put("Buyer ID", "");
                  checkReserve.put("Seller ID", itemInfo.get("Seller ID"));
                  showList.put("C "+itemID[i],checkReserve);
              }
              else{
                  checkReserve.put("Item Name", itemInfo.get("Name"));
                  checkReserve.put("Description", itemInfo.get("Description"));
                  checkReserve.put("Sale Price", Double.toString(bidPrice));
                  checkReserve.put("Buyer ID", bidnode.get("BidderID"));
                  checkReserve.put("Seller ID",itemInfo.get("Seller ID"));
                  showList.put("C "+itemID[i],checkReserve);
              }
            }
           
           else{
                 checkReserve.put("Item Name", itemInfo.get("Name"));
                  checkReserve.put("Description", itemInfo.get("Description"));
                  checkReserve.put("Sale Price", "No Bider");
                  checkReserve.put("Buyer ID", "");
                  checkReserve.put("Seller ID", itemInfo.get("Seller ID"));
                  showList.put("C "+itemID[i],checkReserve);
           }
                
           }
              else {
                if(BidValue.checkTrID(itemID[i])){
                  bidnode=BidValue.highestBid(itemInfo.get("Name"));
                  bidPrice=Double.valueOf(bidnode.get("Value").trim()).doubleValue();
                  checkReserve.put("Item Name", itemInfo.get("Name"));
                  checkReserve.put("Description", itemInfo.get("Description"));
                  checkReserve.put("Sale Price", Double.toString(bidPrice));
                  checkReserve.put("Buyer ID", bidnode.get("BidderID"));
                  checkReserve.put("Seller ID",itemInfo.get("Seller ID"));
                  showList.put("C "+itemID[i],checkReserve);
                }
                else
                {
                  checkReserve.put("Item Name", itemInfo.get("Name"));
                  checkReserve.put("Description", itemInfo.get("Description"));
                  checkReserve.put("Sale Price", "No Bider");
                  checkReserve.put("Buyer ID", "");
                  checkReserve.put("Seller ID", itemInfo.get("Seller ID"));
                  showList.put("C "+itemID[i],checkReserve);  
                }
               }
               
               //System.out.println("item ended:"+list[i]);
               
               //BidValue.removeBidList(itemID[i]);
               list[i]="Closed Item Name:"+checkReserve.get("Item Name")+",Sale Price:"+checkReserve.get("Sale Price")+",Buyer ID:"+checkReserve.get("Buyer ID")+",Seller ID:"+checkReserve.get("Seller ID");
	    }

              i++;        
       }
              // Item.clearList();
             
             //  BidValue.clearBidList();
     
       return showList;
    }
}