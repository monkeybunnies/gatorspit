/*
 * Client.java
 *
 * Created on April 9, 2005, 10:10 AM
 */

/**
 *
 * @author  Andi
 */
import java.util.*;
import java.util.Hashtable;
import java.lang.*;
import java.rmi.server.UnicastRemoteObject;

public class ClientImpl extends java.rmi.server.UnicastRemoteObject implements ClientInterface {
    private Hashtable<String, Hashtable> myWealth;
    private Hashtable<String, Hashtable> mySellList;
    private Hashtable<String, Hashtable> myBidList;

    /** Creates a new instance of Client */
    public ClientImpl() throws java.rmi.RemoteException {
        myWealth = new Hashtable<String, Hashtable>();
        mySellList = new Hashtable<String, Hashtable>();
        myBidList = new Hashtable<String, Hashtable>();
    }
    
    public void ViewMyWealth() throws java.rmi.RemoteException {
        int size = myWealth.size();
        if (size > 0) {
            System.out.println("My deposit: "+myWealth.get("Deposit").get("money"));
            System.out.println("Goods #1");
            System.out.println("Name: "+myWealth.get("CaramelPop").get("name"));
            System.out.println("Unit Price: $ "+myWealth.get("CaramelPop").get("unitPrice"));
            System.out.println("Amount: "+myWealth.get("CaramelPop").get("amount"));
            
            System.out.println("Goods #2");
            System.out.println("Name: "+myWealth.get("AssortedChocolates").get("name"));
            System.out.println("Unit Price: $ "+myWealth.get("AssortedChocolates").get("unitPrice"));
            System.out.println("Amount: "+myWealth.get("AssortedChocolates").get("amount"));
            
            System.out.println("Goods #3");
            System.out.println("Name: "+myWealth.get("Cashews").get("name"));
            System.out.println("Unit Price: $ "+myWealth.get("Cashews").get("unitPrice"));
            System.out.println("Amount: "+myWealth.get("Cashews").get("amount"));
            
            System.out.println("Goods #4");
            System.out.println("Name: "+myWealth.get("VanillaButtercreams").get("name"));
            System.out.println("Unit Price: $ "+myWealth.get("VanillaButtercreams").get("unitPrice"));
            System.out.println("Amount: "+myWealth.get("VanillaButtercreams").get("amount"));
            
            System.out.println("Goods #5");
            System.out.println("Name: "+myWealth.get("HersheysKisses").get("name"));
            System.out.println("Unit Price: $ "+myWealth.get("HersheysKisses").get("unitPrice"));
            System.out.println("Amount: "+myWealth.get("HersheysKisses").get("amount"));
            
            System.out.println("Goods #6");
            System.out.println("Name: "+myWealth.get("KitKatBar").get("name"));
            System.out.println("Unit Price: $ "+myWealth.get("KitKatBar").get("unitPrice"));
            System.out.println("Amount: "+myWealth.get("KitKatBar").get("amount"));
            
            System.out.println("Goods #7");
            System.out.println("Name: "+myWealth.get("TootsieRolls").get("name"));
            System.out.println("Unit Price: $ "+myWealth.get("TootsieRolls").get("unitPrice"));
            System.out.println("Amount: "+myWealth.get("TootsieRolls").get("amount"));
            
            System.out.println("Goods #8");
            System.out.println("Name: "+myWealth.get("JordanAlmonds").get("name"));
            System.out.println("Unit Price: $ "+myWealth.get("JordanAlmonds").get("unitPrice"));
            System.out.println("Amount: "+myWealth.get("JordanAlmonds").get("amount"));
            
            System.out.println("Goods #9");
            System.out.println("Name: "+myWealth.get("AnimalCrackers").get("name"));
            System.out.println("Unit Price: $ "+myWealth.get("AnimalCrackers").get("unitPrice"));
            System.out.println("Amount: "+myWealth.get("AnimalCrackers").get("amount"));
            
            System.out.println("Goods #10");
            System.out.println("Name: "+myWealth.get("CappuccinoChocolate").get("name"));
            System.out.println("Unit Price: $ "+myWealth.get("CappuccinoChocolate").get("unitPrice"));
            System.out.println("Amount: "+myWealth.get("CappuccinoChocolate").get("amount"));
        
        //System.out.println("size "+size);
        }
        else {
            System.out.println("You don't have any wealth yet.");
        }
    }
    /**
     *  getting the amount of specific item
     */
    public double getAmount(String itemName) throws java.rmi.RemoteException {
        String amount = (String) myWealth.get(itemName).get("Amount");
        double Amount = Double.valueOf(amount).doubleValue();
        return Amount;
    }
    
    public double getMoney() throws java.rmi.RemoteException {
        String money = (String) myWealth.get("Deposit").get("money");
        double Money = Double.valueOf(money).doubleValue();
        return Money;
    }
    
    public void addSellList(String trID, String itemName, String amount, String itemDescription,
    String startPrice, String reservePrice, String closingTime) throws java.rmi.RemoteException {
        Hashtable<String, String> item = new Hashtable<String, String>();
        item.put("Name", itemName);
        item.put("Amount", amount);
        item.put("Description", itemDescription);
        item.put("Starting Price", startPrice);
        item.put("Reserve Price", reservePrice);
        item.put("Closing Time", closingTime);
        item.put("Status", "Open");
        mySellList.put((String) trID, (Hashtable) item);
        //substract the amount of goods from inventory
    }
    
    public void showSellList() throws java.rmi.RemoteException {
        if (mySellList.size()>0) {
        for(Enumeration e = mySellList.keys() ; e.hasMoreElements() ;) {
            String key = (String) e.nextElement();
            System.out.println("Transaction ID: "+key);
            System.out.println("Item Name: "+mySellList.get(key).get("Name"));
            System.out.println("Amount: "+mySellList.get(key).get("Amount"));
            System.out.println("Description: "+mySellList.get(key).get("Description"));
            System.out.println("Starting Price: "+mySellList.get(key).get("Starting Price"));
            System.out.println("Reserve Price: "+mySellList.get(key).get("Reserve Price"));
            System.out.println("Closing Time: "+mySellList.get(key).get("Closing Time"));
            System.out.println("Status: "+mySellList.get(key).get("Status"));
            System.out.println("*****************************************************");
        }
        }
        else
            System.out.println("you didn't sell anything yet.");
    }
    
    public void addBidList(String trID, String itemName, String amount, String price, String bidTime) 
    throws java.rmi.RemoteException {
        //check if ever bid this item, if NOT, add trID as key
        if (!myBidList.containsKey((String) trID)) {
            Hashtable<String, String> mybid = new Hashtable<String, String>();
            mybid.put("Name", itemName);
            mybid.put("Bid Value", price);
            mybid.put("Amount", amount);
            mybid.put("Bid Time", bidTime);
            mybid.put("Status", "Open");
            myBidList.put((String) trID, (Hashtable) mybid);
        }
        //if YES, update the bid's information
        else {
            myBidList.get(trID).put("Bid Value", price);
            myBidList.get(trID).put("Bid Time", bidTime);
        }
    }

    public void showBidList() throws java.rmi.RemoteException {
        if (myBidList.size()>0) {
        for(Enumeration e = myBidList.keys() ; e.hasMoreElements() ;) {
            String key = (String) e.nextElement();
            System.out.println("Transaction ID: "+key);
            System.out.println("Item Name: "+mySellList.get(key).get("Name"));
            System.out.println("Bid Value: "+mySellList.get(key).get("Bid Value"));
            System.out.println("Amount: "+mySellList.get(key).get("Amount"));
            System.out.println("Bid Time: "+mySellList.get(key).get("Bid Time"));
            System.out.println("Status: "+mySellList.get(key).get("Status"));
            System.out.println("*****************************************************");
        }
        }
        else
            System.out.println("you didn't bid anything yet.");
    }
    
    /**
     * For initialize myWealth, Clients connect to the server,
     * server will allocate and return the personal wealth.
     */
    
    public void initialWealth(Hashtable wealth) throws java.rmi.RemoteException {
        myWealth.putAll((Hashtable)wealth);
    }
    
    /** Server needs to comfirm the transaction success
     *  The seller gets the money, release the goods it sold.
     *  update the myWealth Hashtable.
     *  update the mySellList status
     */
    public void sellTransaction(String trID, String itemName, String sellAmount, String sellPrice) 
    throws java.rmi.RemoteException {
        double Amount = Double.valueOf(sellAmount).doubleValue();
        double newAmount = this.getAmount(itemName) - Amount;
        String rest = Double.toString(newAmount);
        myWealth.get(itemName).put("Amount", rest);
        double money = Double.valueOf(sellPrice).doubleValue();
        double result = this.getMoney() + money;
        String deposit = Double.toString(result);
        myWealth.get("Deposit").put("money", deposit);
        mySellList.get(trID).put("Status", "sold with $ "+sellPrice);
        System.out.println("Successfully sold item: "+itemName+" amount: "+sellAmount+" in $ "+sellPrice);
    }
    
    public void bidTransaction(String trID, String itemName, String amount, String payment) 
    throws java.rmi.RemoteException {
        double Amount = Double.valueOf(amount).doubleValue();
        double newAmount = this.getAmount(itemName) + Amount;
        String rest = Double.toString(newAmount);
        myWealth.get(itemName).put("Amount", rest);
        double money = Double.valueOf(payment).doubleValue();
        double result = this.getMoney() - money;
        String deposit = Double.toString(result);
        myWealth.get("Deposit").put("money", deposit);
        myBidList.get(trID).put("Status", "bid successfully!");
        
        System.out.println("Successfully bid item: "+itemName+" amount: "+amount+" in $ "+payment);
        
    }
    
    public void failSell(String trID) throws java.rmi.RemoteException {
        System.out.println("failed selling item: "+trID);
        mySellList.get(trID).put("Status", "not sold");
    }
    
    public void failBid(String trID) throws java.rmi.RemoteException {
        System.out.println("failed bidding item: "+trID);
        myBidList.get(trID).put("Status", "bid failed");
    }
    
    public boolean checkAmount(String itemName, String amount) throws java.rmi.RemoteException {
        double inventoryAmount = Double.valueOf((String) myWealth.get(itemName).get("Amount")).doubleValue();
        double sellAmount = Double.valueOf(amount).doubleValue();
        if (inventoryAmount >= sellAmount) {
            return true;
        }
        else
            return false;
    }
    
    public void printMessage (String str) throws java.rmi.RemoteException {
        System.out.println(str);
    }
    
    public void terminateSystem () throws java.rmi.RemoteException {
        System.out.println("sign out system!");
        System.exit(0);
    }
    
    
    public boolean checkMoney(String price) throws java.rmi.RemoteException {
        double deposit = Double.valueOf((String) myWealth.get("Deposit").get("money")).doubleValue();
        double sellPrice = Double.valueOf(price).doubleValue();
        if (deposit >= sellPrice) {
            return true;
        }
        else
            return false;
    }
    
    public double getMyValue() throws java.rmi.RemoteException {
        double deposit = Double.valueOf((String) myWealth.get("Deposit").get("money")).doubleValue();
        
        double unitPrice1 = Double.valueOf((String) myWealth.get("CaramelPop").get("unitPrice")).doubleValue();
        double amount1 = Double.valueOf((String) myWealth.get("CaramelPop").get("amount")).doubleValue();
        double item1 = unitPrice1*amount1;
        
        double unitPrice2 = Double.valueOf((String) myWealth.get("AssortedChocolates").get("unitPrice")).doubleValue();
        double amount2 = Double.valueOf((String) myWealth.get("AssortedChocolates").get("amount")).doubleValue();
        double item2 = unitPrice2*amount2;
        
        double unitPrice3 = Double.valueOf((String) myWealth.get("Cashews").get("unitPrice")).doubleValue();
        double amount3 = Double.valueOf((String) myWealth.get("Cashews").get("amount")).doubleValue();
        double item3 = unitPrice3*amount3;
        
        double unitPrice4 = Double.valueOf((String) myWealth.get("VanillaButtercreams").get("unitPrice")).doubleValue();
        double amount4 = Double.valueOf((String) myWealth.get("VanillaButtercreams").get("amount")).doubleValue();
        double item4 = unitPrice4*amount4;
        
        double unitPrice5 = Double.valueOf((String) myWealth.get("HersheysKisses").get("unitPrice")).doubleValue();
        double amount5 = Double.valueOf((String) myWealth.get("HersheysKisses").get("amount")).doubleValue();
        double item5 = unitPrice5*amount5;
        
        double unitPrice6 = Double.valueOf((String) myWealth.get("KitKatBar").get("unitPrice")).doubleValue();
        double amount6 = Double.valueOf((String) myWealth.get("KitKatBar").get("amount")).doubleValue();
        double item6 = unitPrice6*amount6;
        
        double unitPrice7 = Double.valueOf((String) myWealth.get("TootsieRolls").get("unitPrice")).doubleValue();
        double amount7 = Double.valueOf((String) myWealth.get("TootsieRolls").get("amount")).doubleValue();
        double item7 = unitPrice7*amount7;
        
        double unitPrice8 = Double.valueOf((String) myWealth.get("JordanAlmonds").get("unitPrice")).doubleValue();
        double amount8 = Double.valueOf((String) myWealth.get("JordanAlmonds").get("amount")).doubleValue();
        double item8 = unitPrice8*amount8;
        
        double unitPrice9 = Double.valueOf((String) myWealth.get("AnimalCrackers").get("unitPrice")).doubleValue();
        double amount9 = Double.valueOf((String) myWealth.get("AnimalCrackers").get("amount")).doubleValue();
        double item9 = unitPrice9*amount9;
        
        double unitPrice10 = Double.valueOf((String) myWealth.get("CappuccinoChocolate").get("unitPrice")).doubleValue();
        double amount10 = Double.valueOf((String) myWealth.get("CappuccinoChocolate").get("amount")).doubleValue();
        double item10 = unitPrice10*amount10;
        
        double totalWealth = deposit+item1+item2+item3+item4+item5+item6+item7+item8+item9+item10;
        System.out.println("my personal value is: $"+totalWealth);
        return totalWealth;
    }
}
