/*
 * GameServer.java
 *
 * Created on April 11, 2005, 7:27 PM
 */

/**
 *
 * @author  Andi
 */
import java.util.*;
import java.rmi.Naming; 
import java.rmi.RemoteException; 
import java.net.MalformedURLException; 
import java.rmi.NotBoundException; 

public class GameServer {
    //private GameConsole       clientConsole;
    private RMI           rmi;
    private ServerInterface  server;
    private String         RMI_Port;
    private SellDataStructure selllist;
    private BidDataStructure bidlist;

    
    /** Creates a new instance of ClientSide */
    public GameServer() {
        rmi = new RMI ();
        RMI_Port = "5397";
        selllist = new SellDataStructure();
        bidlist = new BidDataStructure(selllist);
    }
    private void begin(String serverName){
        ServerInterface server = null;
        try {
           server = new ServerImpl(rmi, selllist, bidlist);
           Naming.rebind("rmi://localhost:"+ RMI_Port+"/sli_"+ serverName, server);
        } catch (Exception e) {
           System.out.println("Error when register to RMI. Recheck and try again. ");
           System.exit(0);
        }

        // Create CloseAuction thread .
        
        CloseAuction close = new CloseAuction(selllist, bidlist, rmi, serverName);
        Thread timer = new Thread(close);
        timer.start();
        // create closebid thread
        CloseBid closeItem = new CloseBid(selllist, bidlist, serverName, rmi );
        Thread catcher = new Thread(closeItem);
        catcher.start();
         
    }

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GameServer s = new GameServer();
        if(args.length == 1){
            s.begin(args[0]);
        }
        else{
            System.out.println("java GameServer <GameName>" );
            System.exit(0);
        }
    }
}
