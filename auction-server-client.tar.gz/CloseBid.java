/*
 * CloseBid.java
 *
 * Created on April 12, 2005, 5:16 PM
 */
import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.concurrent.*;
/**
 *
 * @author sli
 */
public class CloseBid extends Thread implements Runnable {
    SellDataStructure sellList;
    BidDataStructure bidList;
    RMI  rmi;
    String serverName;
    //RegisterClient clientlist;

    //CountDownLatch counter;
    /** Creates a new instance of CloseBid */
    public CloseBid(SellDataStructure itemList, BidDataStructure bidlist, String serverName, RMI rmi) {
        this.sellList=itemList;
        this.bidList=bidlist;
        this.serverName = serverName;
        this.rmi = rmi;
        //this.clientlist = new RegisterClient(serverName);
        //counter=ct;
    }
    
   public void run()
   {
      
      //HashMap<String,HashMap> showList=new HashMap<String,HashMap>();
      // itemList=new HashMap<String,HashMap>();
      //HashMap<String,String> record=new HashMap<String,String>();
      long start = System.currentTimeMillis();
      long end = System.currentTimeMillis();
      //int i;
      while(end-start<5000){
       //System.out.println("Still looping");
       try{
        Thread.sleep(1000);
        }
        catch(Exception e){
            System.out.println(e);
        }
       updateList();
       /*
       GameOver BidClose=new GameOver(sellList,bidList); 
       HashMap<String,HashMap> showList=BidClose.gameOver();
       Iterator iterator = showList.keySet().iterator();
       HashMap<String,HashMap> itemList=sellList.viewSellList();
       
       while (iterator.hasNext()) {
	   String key = (String)iterator.next();
           String flag=key.substring(0,1);
           String itemKey=key.substring(2);
           System.out.println("Item's "+itemKey+"flag is:"+flag);
            Iterator it = itemList.keySet().iterator();
            /*if(!it.hasNext()) System.out.println("No item");
            while(it.hasNext()){
                String ilist=(String)it.next();
                System.out.println("key is:"+ilist);
            }
           */     
         /*  if(flag.equals("C")){
               if(itemList.containsKey(itemKey)){
               HashMap<String,String> item=itemList.get(itemKey);
               //String status=item.get("Status");
               //System.out.println(itemKey+"'s status is:"+status);
               if(item.get("Status").equals("Open")){
                   itemList.get(itemKey).put("Status","Close");
                  System.out.println("send message to client with "+itemKey);
                  //send message to client
               }
               }
               else System.out.println("doesn't exist itemkey");
           }
          
       
       }*/
       end = System.currentTimeMillis();
       
      }
       //counter.countDown();
   }
   
   public synchronized void updateList(){
       GameOver BidClose=new GameOver(sellList,bidList); 
       HashMap<String,HashMap> showList=BidClose.gameOver();
       Iterator iterator = showList.keySet().iterator();
       HashMap<String,HashMap> itemList=sellList.viewSellList();
       if(iterator.hasNext()){
       while (iterator.hasNext()) {
	   String key = (String)iterator.next();
           String flag=key.substring(0,1);
           String itemKey=key.substring(2);
           System.out.println("Item's "+itemKey+"flag is:"+flag);
            Iterator it = itemList.keySet().iterator();
            /*if(!it.hasNext()) System.out.println("No item");
            while(it.hasNext()){
                String ilist=(String)it.next();
                System.out.println("key is:"+ilist);
            }
           */     
           if(flag.equals("C")){
 
               if(itemList.containsKey(itemKey)){
               HashMap<String,String> item=itemList.get(itemKey);
               //String status=item.get("Status");
               //System.out.println(itemKey+"'s status is:"+status);
               if(item.get("Status").equals("Open")){
                   itemList.get(itemKey).put("Status","Close");
                  System.out.println("send message to client with "+itemKey);
                  HashMap<String,String> sbID=showList.get(key);
                  String sellerID=sbID.get("Seller ID");
                  String buyerID=sbID.get("Buyer ID");
                  boolean canSell = false;
                  boolean canBuy = false;
                  String itemName = sellList.getItemName(itemKey);
                  if(!buyerID.equals("")){
                     ClientInterface s = rmi.getMyClient(sellerID+"_on_"+serverName);
                     ClientInterface b = rmi.getMyClient(buyerID+"_on_"+serverName);
                     String sellPrice=sbID.get("Sale Price");
                     String sellAmount = sellList.getAmount(itemKey);
                     
                     
                     try {
                        canSell = s.checkAmount(itemName, sellAmount);
                        canBuy = b.checkMoney(sellPrice);
                    
                     } catch (Exception ex) {System.out.println(ex);}
                     if (canSell && canBuy) {
                        try {
                            s.sellTransaction(itemKey, itemName, sellAmount, sellPrice);
                            s.printMessage("Sell Item "+itemName+" SUCCESSFULLY!");
                            b.bidTransaction(itemKey, itemName, sellAmount, sellPrice);
                            b.printMessage("Buy Item "+itemName+" SUCCESSFULLY!");
                        } catch (Exception ex) {System.out.println(ex);}
                     }
                     else {
                        try {
                            s.failSell(itemKey);
                            s.printMessage("Sell Item "+itemName+" FAILED!");
                            b.failBid(itemKey);
                            b.printMessage("Bid Item "+itemName+" FAILED!");
                        } catch (Exception ex) {System.out.println(ex);}
                     }
                  }
                  else {
                      buyerID = bidList.getBidderID(itemKey);
                      ClientInterface s = rmi.getMyClient(sellerID+"_on_"+serverName);
                      ClientInterface b = rmi.getMyClient(buyerID+"_on_"+serverName);
                      try {
                      s.failSell(itemKey);
                      s.printMessage("Sell Item "+itemName+" FAILED!");
                      b.failBid(itemKey);
                      b.printMessage("Bid Item "+itemName+" FAILED!");
                      }catch(Exception e) {System.out.println(e);}
                  }
                  //send message to client
               }
               }
               else System.out.println("doesn't exist itemkey");
           }
       }
   }
       else System.out.println("Empty list!");
   }
   
}
