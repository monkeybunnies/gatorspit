/*
 * RegisterClient.java
 *
 * Created on April 10, 2005, 4:59 PM
 */

/**
 *
 * @author  Andi
 */
import java.util.*;
import java.util.HashMap;

public class RegisterClient extends Thread{
    private static HashMap<String, String> ClientTable = new HashMap<String, String>();
    //private Inventory allocation;
    private static int index = 1;
    //private String CID;
    private String serverName;
    private RMI rmi;
    
    /** Creates a new instance of RegisterClient */
    public RegisterClient( String serverName) {
        //allocation = new Inventory();
        //this.CID = CID;
        this.serverName = serverName;
        rmi = new RMI();
        
    }
    
    public synchronized String registerNewClient(String CID) {
        if (ClientTable.containsValue(CID)) {
            System.out.println(CID+" already exist, please try signin with another user ID.");
            return "00";
        }
        else {
            //store in clienttable
            System.out.println(CID+" Sign in successfully!");
            //System.out.println("My personal wealth is: "+myWealth);
            String index1;
            index1 = Integer.toString(index);
            //System.out.println("Deposite: $"+myWealth.get("Deposite").get("money"));
            
            ClientTable.put(index1, CID);
            index ++;
            return CID;
        }
    }
    
    public HashMap getClientList() {
        return (HashMap)ClientTable;
    }
}
