/*
 * SellDataStructure.java
 *
 * Created on April 3, 2005, 12:19 PM
 */

/**
 *
 * @author  Andi
 */
import java.util.*;
import java.util.HashMap;

public class SellDataStructure {
    private static int transactionID = 1;
    private static HashMap<String, HashMap> itemList;
    private Calendar cal = new GregorianCalendar();
    BidDataStructure getBidValue;

    
    /** Creates a new instance of SellDataStructure */
    public SellDataStructure() {
        itemList = new HashMap<String, HashMap>();
        getBidValue = new BidDataStructure(this);
    }
   /**
    * Add a new item into the sale list, generate a unique transactionID,
    * input: itemname
    *        amount
    *        description
    *        sellerID
    *        startprice
    *        reserveprice(optional)
    *        closingTime
    *output: true or false
    *        if add successfully return true
    *        otherwise, false
    */
    public synchronized String addSellList(String itemName, String amount, String itemDescription,
    String CID, String startPrice, String reservePrice, String closingTime) {
        //get system time
        int hour24 = cal.get(Calendar.HOUR_OF_DAY);
        int min = cal.get(Calendar.MINUTE);
        int sec = cal.get(Calendar.SECOND);
        // check the closingTime whether greater than systemtime
        double systemTime = hour24*3600 + 60*min + sec;
        if (systemTime < this.changeTimeFormat(closingTime)) {
            HashMap<String, String> inventory;
            inventory = new HashMap<String, String>();                                    
            inventory.put("Name", itemName);
            inventory.put("Amount", amount);
            inventory.put("Description", itemDescription);
            inventory.put("Starting Price", startPrice);
            inventory.put("Reserve Price", reservePrice);
            inventory.put("Closing Time", closingTime);
            inventory.put("Status", "Open");
            inventory.put("Seller ID", CID);

            String trID = Integer.toString(transactionID);
            itemList.put((String) trID, (HashMap) inventory);
            transactionID ++;
            return trID;
        }
        else
            return "0";
    }
    
    /**  for list the items for sale
     *   return the itemList
     */
    public HashMap viewSellList() {
        return itemList;
    }
    
    /**
     * empty the whole itemList!!!
     */
    public void clearList(){
       // System.out.println("remove item:"+trID);
        itemList.clear();
    }
    
    /**
     *   for edit the description
     *   input: sellerID        CID
     *          transactionID   trID
     *          description     Description
     *   output: true or false
     *           if update successfully return true
     *           else false
     */
    public synchronized boolean editDescription(String CID, String trID, String Description) {
        if (itemList.containsKey((String) trID)) {
            HashMap getMyItem = (HashMap) itemList.get((String) trID);
            if (getMyItem.get("Seller ID").equals(CID)) {
                getMyItem.remove("Description");
                getMyItem.put("Description", (String) Description);
                return true;
            }
            else {
                return false;
            }
        }
        else
            return false;
    }
    
    /** for delete a item from sale list
     *  this happened when: 1. the auction is deal,
     *  2. the auction is close due to timeout.
     *  only the server have the right to delete the item
     *  input:    transactionID
     *  output:   true or false (indicate success or not)
     */
    public boolean deleteItem(String trID) {
        if (itemList.containsKey((String) trID)) {
            itemList.remove((String) trID);
            return true;
        }
        else
            return false;
    }
    
    /**
     * to get the transaction ID which reached the close time
     * input:  currentTime, ex: 7:45, 13:10
     * output: trID
     */
     public HashMap getClosedItem() {
         //get the system time
          int hour24 = cal.get(Calendar.HOUR_OF_DAY);
          int min = cal.get(Calendar.MINUTE);
          double systemTime = hour24 + .01*min;
          //define the HashMap store the closed Item.
          HashMap<String, HashMap> closedItemList;
          closedItemList = new HashMap<String, HashMap>();
          HashMap<String, String> closedItemInfo;
          closedItemInfo = new HashMap<String, String>();
          //in the for loop, all the items in the sell list 
          //will be checked one by one
          int itemListSize = itemList.size();
          for (int i = 0; i < itemListSize; i ++) {
              String key = Integer.toString(i+1);
              String closeTime = (String) itemList.get(key).get("Closing Time");
              if (systemTime >= this.changeTimeFormat(closeTime)) {
                  //check if the due item has a bid
                  if (getBidValue.checkTrID(key)) {
                      HashMap<String, String> highestBid;
                      highestBid = (HashMap) getBidValue.highestBid(key);
                      String value = highestBid.get("Value");
                      //double price = Double.valueOf((String)value).doubleValue();
                      //double reservePrice = Double.valueOf((String) itemList.get(key).get("Reserve Price")).doubleValue();
                      //if so, check the bid value already reached the reserve price
                      if (getBidValue.MeetReservePrice(key)) {
                          itemList.get(key).put("Status", "closed");
                          closedItemInfo.put("SellerID", (String) itemList.get(key).get("Seller ID"));
                          closedItemInfo.put("itemName", (String) itemList.get(key).get("Name"));
                          closedItemInfo.put("Amount", (String) itemList.get(key).get("Amount"));
                          closedItemInfo.put("BidderID", (String) highestBid.get("BidderID"));
                          closedItemInfo.put("Value", value);
                          closedItemInfo.put("Status", "sold");
                          closedItemList.put(key, (HashMap) closedItemInfo);
                      }
                      else {
                          itemList.get(key).put("Status", "closed");
                          closedItemInfo.put("SellerID", (String) itemList.get(key).get("Seller ID"));
                          closedItemInfo.put("itemName", (String) itemList.get(key).get("Name"));
                          closedItemInfo.put("Amount", (String) itemList.get(key).get("Amount"));
                          closedItemInfo.put("BidderID", (String) highestBid.get("BidderID"));
                          closedItemInfo.put("Value", value);
                          closedItemInfo.put("Status", "closed");
                          closedItemList.put(key, (HashMap) closedItemInfo);
                      }
                  }
                  else {
                      itemList.get(key).put("Status", "closed");
                      closedItemInfo.put("SellerID", (String) itemList.get(key).get("Seller ID"));
                      closedItemInfo.put("itemName", (String) itemList.get(key).get("Name"));
                      closedItemInfo.put("Amount", (String) itemList.get(key).get("Amount"));
                      closedItemInfo.put("BidderID", "0");
                      closedItemInfo.put("Value", "0");
                      closedItemInfo.put("Status", "closed");
                      closedItemList.put(key, (HashMap) closedItemInfo);
                  }
              }
              else {
              }
          }
          return (HashMap) closedItemList;
     }
     
     public double changeTimeFormat(String closetime) {
         String[] h=new String[3];
           int j=0,k=0,l=0;
           char time[]=closetime.toCharArray();
           for(j=0;j<closetime.length();j++){
               //System.out.println(j+","+k+","+l);
               if(time[j]==':'){
                   h[l]=closetime.substring(k,j);
                   //System.out.println("h["+l+"] is:"+h[l]);
                   k=j+1;
                   l++;
               }           
           }
           h[2]=closetime.substring(k,j);
           System.out.println("close time is "+h[0]+":"+h[1]+":"+h[2]);
           double hr=Double.valueOf(h[0].trim()).doubleValue();
           double m=Double.valueOf(h[1].trim()).doubleValue();
           double s=Double.valueOf(h[2].trim()).doubleValue();
           double icTime=hr*3600+m*60+s;
           return icTime;
           
           
           
     }
     
     public boolean checkItemStatus(String trID) {
         if (itemList.containsKey(trID)) {
             if (itemList.get(trID).get("Status").equals("open")) {
                 return true;
             }
             else
                 return false;
         }
         else 
             return false;
     }
     
     public double getReservePrice(String trID) {
         String reservePrice = (String) itemList.get(trID).get("Reserve Price");
         double reserveValue = Double.valueOf((String)reservePrice).doubleValue();
         return reserveValue;
     }
     
     public String getSellerID(String trID) {
         String SellerID = (String)itemList.get(trID).get("Seller ID");
         return SellerID;
     }
     
     public String getItemName(String trID) {
         String itemName = (String)itemList.get(trID).get("Name");
         return itemName;
     }
     
     public String getAmount(String trID) {
         String amount = (String)itemList.get(trID).get("Amount");
         return amount;
     }

     public boolean checkTrID(String trID) {
         if (itemList.containsKey((String) trID)) {
             return true;
         }
         else
             return false;
     }
     
     public String getHighestBid(String trID) {
         if (getBidValue.checkTrID(trID)) {
              HashMap<String, String> highestBid;
              highestBid = (HashMap) getBidValue.highestBid(trID);
              String value = highestBid.get("Value");
              return value;
         }
         else
             return "";
     }
     public boolean isEmpty() {
         if ((int)itemList.size() == 0)
             return true;
         else
             return false;
     }
}

