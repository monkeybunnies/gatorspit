/**
 *
 * @author Xin Fu
 */
import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.concurrent.*;

class ServerAddBid extends Thread implements Runnable{
    String trID;
    String price;
    String bID;
    BidDataStructure addbid;
    SellDataStructure sell;
    RMI rmi;
    String serverName;
    //CountDownLatch cnt;

    
    /** Creates a new instance of ServerOpt */
    public ServerAddBid(String tranID, String bidderID, String intialprice,BidDataStructure bidview, 
    String serverName, RMI rmi) {
       trID=tranID;
       bID=bidderID;
       price=intialprice;
       //cnt=totalcounter;
       addbid=bidview;
       this.rmi = rmi;
       this.serverName = serverName;
       this.sell = new SellDataStructure();
    }
    public void run(){ 
        String bidPrice;
        String bTime;
        
        boolean success=false;
        ClientInterface c = rmi.getMyClient(bID+"_on_"+serverName);
        Calendar cal = new GregorianCalendar();
        int hour24 = cal.get(Calendar.HOUR_OF_DAY);             // 0..59
        int min = cal.get(Calendar.MINUTE);             // 0..59
        int sec = cal.get(Calendar.SECOND);             // 0..59
        double bidTime = hour24*3600 +60*min+sec;
        bTime = Double.toString(bidTime);
        if (addbid.entryBidList(trID, price)) {
            bidPrice=addbid.proxyBid((String) trID, (String) price);
            if(addbid.checkProx((String)trID)){
                //proxy bid is higher, report bid failure to the client.
                try {
                    c.printMessage("Add bid for item: "+trID+" FAILED! - bid price lower than the proxy bid price");
                }catch (Exception e) {System.out.println(e);}
                
                String proxybID=addbid.getBidderID((String)trID);
                
                if (!proxybID.equals(bID)) {
                    success=addbid.addBidList((String)trID, (String)proxybID, (String)bidPrice, (String)bTime);
                    ClientInterface p = rmi.getMyClient(proxybID+"_on_"+serverName);
                    try {
                        success = p.checkMoney(bidPrice);
                    } catch(Exception e) {System.out.println(e);}
                    if (success) {
                        String itemName = sell.getItemName(trID);
                        String amount = sell.getAmount(trID);
                        String str = "Add proxy bid for item: "+itemName+" SUCCESSFULLY!";
                        try {
                            p.addBidList(trID, itemName, amount, bidPrice, bTime);
                            p.printMessage(str);

                        } catch (Exception e) {System.out.println(e);}
                    }
                    else {
                        String str = "Add proxy bid for item: "+sell.getItemName(trID)+" FAILED!";
                        try {
                            p.printMessage(str);
                        } catch (Exception e) {System.out.println(e);}
                    }
                }
                else
                    try {
                        c.printMessage("You already setup proxy bid for item: "+trID);
                    } catch (Exception e) {System.out.println(e);}
               //report success or failure to client.
            }
                     /**
                     * the current bidder's bid price is lower than highest proxy bids
                     *and don't need to worry whether HashMap proxybids has the trID. 
                     *Because returned price is different from current price, which means 
                     *that item already has proxy bids.
                     **/

            else{
                //get the current system's time
                success=addbid.addBidList((String)trID, (String)bID, (String)price, (String)bTime);
                String itemName = sell.getItemName(trID);
                String amount = sell.getAmount(trID);
                try {
                    success = c.checkMoney(price);
                } catch (Exception e) {System.out.println(e);}
                if (success) {
                    
                    try {
                        c.addBidList(trID, itemName, amount, price, bTime);
                        c.printMessage("Add bid for item: "+trID+" SUCCESSFULLY!");
                    } catch (Exception e) {System.out.println(e);}
                }
                else
                    try {
                        c.printMessage("Add bid for item: "+trID+" FAILED!");
                    } catch (Exception e) {System.out.println(e);}
            }
        }
        else
            try {
                c.printMessage("The bid price is lower than the present bid price");
            } catch (Exception e) {System.out.println(e);}
    }
}


