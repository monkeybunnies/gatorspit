/*
 * ServerInterface.java
 *
 * Created on April 11, 2005, 4:24 PM
 */

/**
 *
 * @author  Andi
 */
import java.util.*;

public interface ServerInterface extends java.rmi.Remote {
    
    public String registerNewClient(String CID, String serverName) throws java.rmi.RemoteException;
    
    public void getMyGoods(String clientID, String serverName) throws java.rmi.RemoteException;
    
    public void addSellItem(String name, String amount, String desc, String startPrice, 
    String reservePrice, String closeTime, String CID, String connectedServer) throws java.rmi.RemoteException;
    
    public void addBid(String trID, String CID, String bidValue, String connectedServer) throws java.rmi.RemoteException;
    
    public void addProxyBid(String trID, String CID, String bidValue, String highest, String connectedServer)
    throws java.rmi.RemoteException;
    
    public void viewItemList(String CID, String connectedserver) throws java.rmi.RemoteException;
    
    public void viewBidList(String trID, String CID, String connectedserver) throws java.rmi.RemoteException;
    
    public void viewClosedItem(String CID, String connectedserver) throws java.rmi.RemoteException;
}
