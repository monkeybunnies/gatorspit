
import java.util.*;
import java.util.HashMap;
import java.lang.*;

public class BidDataStructure {
    HashMap<String, HashMap> bidItem;
    HashMap<String, HashMap> proxybids;
    SellDataStructure sell;
    //private static HashMap<String, HashMap> bidList;
    
    /** Creates a new instance of BidDataStructure */
     public BidDataStructure(SellDataStructure item) {
        //bidList = new HashMap<String, HashMap>();
        this.sell = item;
        bidItem =new HashMap<String, HashMap>();
        proxybids=new HashMap<String, HashMap>();
    }
    /**
     *add a bid into the bidList
     *input:  transactionID    trID
     *        bidderID         bID
     *        price offered    price
     *        time bid         bTime
     *output: true or false
     */
    public synchronized boolean addBidList(String trID, String bID, String price, String bTime) {
        
        if (sell.checkItemStatus(trID)) {
            // TRUE means this item is exist and is currently OPEN.
            // then, verify if the transaction ID already exist in
            // the bidItem list.
              if(entryBidList((String)trID, (String)price)) {
                    if (bidItem.containsKey((String) trID)) {
                            HashMap<String, String> myBid;
                            myBid = new HashMap<String, String>();
                            myBid.put("BidderID", bID);
                            myBid.put("Value", price);
                            myBid.put("Bid Time", bTime);
                            bidItem.get((String) trID).put((String)price, (HashMap)myBid);
                            return true;
                    }
                    else {
                        HashMap<String, String> myBid;
                        HashMap<String, HashMap> bidList;
                        myBid = new HashMap<String, String>();
                        myBid.put("BidderID", bID);
                        myBid.put("Value", price);
                        myBid.put("Bid Time", bTime);
                        bidList = new HashMap<String, HashMap>();
                        bidList.put((String)price, (HashMap)myBid);
                        bidItem.put((String)trID, (HashMap)bidList);
                        return true;
                    }
              }
              else 
              {
                  System.out.println("the bid value should be higher than the present bid value.");
                  return false;
              }
        }
        else
            System.out.println("the item is currently closed.");
            return false;
    }
    
    /** for view the bidList of specific item
     *  input:  transaction ID
     *  output: the bidList of this item
     */
    public HashMap viewBidList(String trID) {
        return bidItem.get((String) trID);
    }
   public String[] getMyBid(String trID) {
       HashMap<String, HashMap> bidlist=bidItem.get((String)trID);
       Iterator iterator = bidlist.keySet().iterator();
       String[] bIDString=new String[bidlist.size()];
       String[] mybid=new String[bidlist.size()];
       int i=0;
       while (iterator.hasNext()) {
	       bIDString[i] = (String)iterator.next();
               HashMap myBid=bidlist.get(bIDString[i]);
               mybid[i]="BidderID:"+myBid.get("BidderID")+",Value:"+myBid.get("Value")+",Bid Time "+myBid.get("Bid Time");
               i++;
	    }
       return(String[]) mybid;
    }   
   
   public String[] bidItemView(){
        Iterator iterator = bidItem.keySet().iterator();
        String[] tranID=new String[bidItem.size()];
        int i=0;
	   while (iterator.hasNext()) {
	       tranID[i] = (String)iterator.next();
               i++;
	    }
        return(String[]) tranID;
   }
   
   
   
   
    /**
     *when the auction ends or timeout, the bids
     *will be removed from the bid list.
     *input: transactionID
     *output: the bid list
     *
     *
     *NOTE: must first execute highestBid(), then removeBid()!
     */
    public HashMap removeBid(String trID) {
        HashMap<String, HashMap> finalBid;
        finalBid = bidItem.get((String)trID);
        bidItem.remove((String) trID);
        return (HashMap) finalBid;
    }
    
    /**Empty the whole bidList!!
     * be careful
     */
    public void clearBidList() {
        bidItem.clear();
   
    }

    /**
     *when the acution ends or timeout, will return 
     *the information of the highest bid. 
     *input: transactionID
     *output: the highest bid information, including
     *the bidderID, the price, the bidTime. The bidderID is 
     *probably to be the buyerID if the price is higher than 
     *reserved price.
     **/
    
    public HashMap highestBid(String trID){
       HashMap<String, HashMap> finalBid;
       HashMap<String, HashMap> largestBid;
       String highest;
       double priceValue=0.0;
       finalBid=bidItem.get((String)trID);
       priceValue=getKey((HashMap<String,HashMap>)finalBid);
       highest=Double.toString(priceValue);
       largestBid=finalBid.get((String)highest);
       return (HashMap) largestBid;
   }
    
    /**
     *get the highest price for a certain Item.
     *input: bidnode 
     *       the bidlist for a certain Item.
     *output:priceValue
     *       the highest bidded price for that item.
     */
    
    
    public Double getKey(HashMap<String, HashMap> bidnode){
       //Set priceSet=Collections.synchronizedSet(new HashSet());
       int i=0;
       int size=0;
       double priceValue=0.0;
       size=bidnode.size();
       String[] priceString=new String[size];
       
       Iterator iterator = bidnode.keySet().iterator();
	while (iterator.hasNext()) {
	    priceString[i] = (String)iterator.next();
            //System.out.println("the priceString is:"+priceString[i]);
            i++;
	    }
       //priceSet=bidnode.keys();
       //priceString=(String[])(bidnode.keySet().toArray());
      // priceString=(String[])priceSet.toArray();
       for(i=0;i<size;i++){
        try {
          double d = Double.valueOf(priceString[i].trim()).doubleValue();
          if(d>priceValue)
                  priceValue=d;
          //System.out.println("double d = " + d);
          } catch (NumberFormatException nfe) {
           System.out.println("NumberFormatException: " + nfe.getMessage());
          }
       }
       return(double) priceValue;
    
    }
    
    /**
     *check whether the new bid price is higher than the bid prices 
     *which already exist in the bidList. 
     *
     */
    
    public boolean entryBidList(String trID, String price){
        if (bidItem.containsKey((String) trID)) {
          HashMap<String, HashMap> largestBid;
          double priceValue=0.0;
          largestBid=bidItem.get((String)trID);
          priceValue=getKey((HashMap<String,HashMap>)largestBid);
          double d = Double.valueOf(price.trim()).doubleValue();
          if(priceValue<d)
              return true;
          else {
              
             System.out.println("there is a bid price "+Double.toString(priceValue)+" which is higher than "+price);
             
              return false;
          }
        }
        else 
            return true;
    }
    /**
     *check whether transaction ID is exist in bidItem
     **/    
    public boolean checkTrID(String trID) {
        if (bidItem.containsKey(trID)) {
            return true;
        }
        else
            return false;
    }
    
    public boolean checkProx(String trID){
        if(proxybids.containsKey(trID))
            return true;
        else return false;
    }
    /**
     *client requires proxy bids, then after addBidList, call proxyBidQueue, 
     * generates proxy bids for certain Item. 
     * return false if endPrice is not higher than intialPrice
     */
    public synchronized boolean proxyBidValue(String trID, String bID, String endPrice){
       
      
       double ePrice;
       ePrice=Double.valueOf(endPrice.trim()).doubleValue();
       //if(!bidItem.containsKey(trID)) 
       ////{
       //    System.out.println("trID doesn't exist.---"+trID);
       //    return false;
       //}
      // else{
       double highbid=getKey(bidItem.get((String)trID));
       if(highbid>ePrice) 
       {
           System.out.println("proxy bid price is lower than current highest bid");
           return false;
       }
       else{
              HashMap<String, String> bIDbids=new HashMap<String, String>();
              bIDbids.put((String)bID, (String)endPrice);
              proxybids.put((String)trID, (HashMap)bIDbids);
              return true;
           }
     //   }
    }
   
  /**
   * 
   **/

  /**
   *every time there is a bid price for a certain item, 
   *need to check whether there is a proxy bid, if true,
   * whether it is higher than the endPrice
   *of proxy bid. If it is, ends proxy bids. Add that bid 
   *into bid list.
   */
   public synchronized String proxyBid(String trID, String price/*new coming bid price*/){
       //System.out.println("trID, price:"+trID+","+price);
          System.out.println("new coming bid price:"+price);
         if(proxybids.containsKey((String)trID)){
           double bPrice=Double.valueOf(price.trim()).doubleValue();
           HashMap<String, String> bIDbids=proxybids.get((String)trID);
           String bidderID=getBidderID((String)trID);
           System.out.println("get proxy bidder ID:"+bidderID);
           String bidPrice=bIDbids.get((String)bidderID);
           System.out.println("get proxy end price:"+bidPrice);
           double endPrice=Double.valueOf(bidPrice.trim()).doubleValue();
           if(bPrice<endPrice){
            if(endPrice>bPrice*1.1){
                  bPrice=bPrice*1.1;
                  price=Double.toString(bPrice);
                  //System.out.println("add bid list price 1:"+price);
                  return price;
             }
             else return bidPrice;
           }
           else{
               proxybids.remove((String)trID);
               //System.out.println("add bid list price 2:"+price);
               return price;
            }
         }  
         else 
         {
           //System.out.println("no proxy bids");
           //System.out.println("add bid list price 3:"+price);
           return price;
         }
         /**
          * after return, compare the retured price with the 
          * current coming bid price to decide who shoule be
          * the bidder now.
          **/
       }
    
   
      public String getBidderID(String trID){
           Set bIDSet=new HashSet();
           HashMap<String, String> bIDbids=proxybids.get((String)trID);
           
           String bIDString="";
           if(proxybids.containsKey(trID)){
               Iterator iterator = bIDbids.keySet().iterator();
               while (iterator.hasNext()) {
                   bIDString = (String)iterator.next();
                   System.out.println("new bidder is:"+bIDString);
                }
           }
           
          // bIDSet=(HashSet)bIDbids.keySet();
           //String[] bIDString=(String[])bIDSet.toArray();
           return(String) bIDString;
           //only one bidder can have proxy bid for a certain item
      }
      
      public boolean MeetReservePrice(String trID) {
          double highestPrice = getKey(bidItem.get((String)trID));
          if (sell.getReservePrice(trID) <= highestPrice) {
              return true;
          }
          else
              return false;
      }
   
}
