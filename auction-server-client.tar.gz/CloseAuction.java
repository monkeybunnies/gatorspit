
import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.concurrent.*;
/**
 *
 * @author Xin Fu
 */
class CloseAuction extends Thread implements Runnable {
    private final double auctionTime=0.30;
    SellDataStructure sellList;
    BidDataStructure bidList;
    RegisterClient clientlist;
    RMI rmi;
    String serverName;
    //CountDownLatch count;
    /** Creates a new instance of CloseAuction */
    public CloseAuction(SellDataStructure itemList,BidDataStructure bidlist,RMI rmi, String serverName) {
        sellList=itemList;
        bidList=bidlist;
        this.rmi = rmi;
        this.serverName = serverName;
        clientlist = new RegisterClient(serverName);

        //count=ct;
    }
    public void run(){
        GameOver gameover=new GameOver(sellList,bidList);
        //Calendar cal = new GregorianCalendar();
        //int min = cal.get(Calendar.MINUTE);             // 0..59
        //int sec = cal.get(Calendar.SECOND);             // 0..59 
        //String currentTime=Integer.toString(min)+"."+Integer.toString(sec);
        //double beginTime=Double.valueOf(currentTime.trim()).doubleValue();
        //double cTime;
        //System.out.println("Starting time:"+beginTime);
        long start = System.currentTimeMillis();
        System.out.println("the start time is:"+start);
       /* while(true){
        min = cal.get(Calendar.MINUTE);             // 0..59
        sec = cal.get(Calendar.SECOND);             // 0..59 
        currentTime=Integer.toString(min)+"."+Integer.toString(sec);
        cTime=Double.valueOf(currentTime.trim()).doubleValue();
        if((cTime-beginTime)>=auctionTime) break;
        }*/
        //game is over, need to show the list
        try{
        Thread.sleep(180000);
        }
        catch(Exception e){
            System.out.println(e);
        }
        //min = cal.get(Calendar.MINUTE);             // 0..59
        //sec = cal.get(Calendar.SECOND);             // 0..59 
        //currentTime=Integer.toString(min)+"."+Integer.toString(sec);
        //System.out.println("Starting time 1:"+currentTime);
        long end = System.currentTimeMillis();
        System.out.println("the end time is:"+end);
        System.out.println("the game is set to last for:"+((end-start)/1000)+" seconds");
        //System.out.println("Starting time 2:"+currentTime);
        //get client reference to announce the auction closed
        Hashtable<String, String> clientList = new Hashtable<String, String> ();
        clientList.putAll((HashMap)clientlist.getClientList());
        for (Enumeration e = clientList.keys() ; e.hasMoreElements() ;) {
            String key = (String) e.nextElement();
            String CID = clientList.get(key);
            ClientInterface c = rmi.getMyClient(CID+"_on_"+serverName);
            try {
                c.printMessage("The auction game "+serverName+" is over!");
                c.getMyValue();
            } catch (Exception er) {System.out.println(er);}
            
        }
        HashMap<String,HashMap> showList=gameover.gameOver();
        Iterator iterator = showList.keySet().iterator();
        while (iterator.hasNext()) {
	   String key = (String)iterator.next();
           System.out.println("closeAuction "+key);
        }
        sellList.clearList();
        bidList.clearBidList();
        /*String[] showList=gameover.gameOver();
        //System.out.println("Game Over:"+currentTime);
        for(int i=0;i<showList.length;i++)
             System.out.println(showList[i]);
         **/
        //count.countDown();
        
    }
    
}
