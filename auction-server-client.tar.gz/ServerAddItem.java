import java.util.*;
import java.util.HashMap;
import java.lang.*;
import java.util.concurrent.*;
/**
 *
 * @author Xin Fu
 */
class ServerAddItem implements Runnable {
    String itemName;
    String Amount;
    String itemDescription;
    String startPrice;
    String reservePrice;
    String closeTime;
    String sellerID;
    String serverName;
    SellDataStructure sellItem;
    RMI rmi;
    //CountDownLatch cnt;
    /** Creates a new instance of ServerAddItem */
    public ServerAddItem(String itemname,String amount,String itemdescription, String startprice, 
    String reserveprice, String closetime, String sellid, String serverName, SellDataStructure sellitem, RMI rmi) {
        itemName=itemname;
        Amount=amount;
        itemDescription=itemdescription;
        startPrice=startprice;
        reservePrice=reserveprice;
        closeTime=closetime;
        sellerID=sellid;
        //cnt=totalcounter;
        sellItem=sellitem;
        this.serverName = serverName;
        this.rmi = rmi;

    }
    public void run(){
        //System.out.println("add sell list:"+itemName);
        boolean success=false;
        String trID = "0";
        
        ClientInterface c = rmi.getMyClient(sellerID+"_on_"+serverName);
        try{
            success = (boolean) c.checkAmount(itemName, Amount);
        }
        catch (java.rmi.RemoteException e){System.out.println("Remote Exception :");
        }
        if (success) {
            trID = sellItem.addSellList(itemName, Amount, itemDescription,sellerID, startPrice, reservePrice, closeTime);
            if (!trID.equals("0")) {
                try {
                    c.addSellList(trID, itemName, Amount, itemDescription, startPrice, reservePrice, closeTime);
                    c.printMessage("Add sell item: "+itemName+" SUCCESSFULLY!");
                } catch (Exception e) {System.out.println(e);}
                
            }
            else
                try {
                    c.printMessage("Failed add sell item: "+itemName+"! -closing time is earlier than system current time");
                } catch (Exception e) {System.out.println(e);}
        }
        else
            try {
                c.printMessage("Failed add sell item: "+itemName+"! -you do not have enough amount to sell");
            } catch (Exception e) {System.out.println(e);}
        //System.out.println("item add successfully?:"+success);
        //cnt.countDown();
    }
    
    
}
