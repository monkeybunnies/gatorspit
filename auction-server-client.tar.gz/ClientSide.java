/*
 * ClientSide.java
 *
 * Created on April 10, 2005, 11:51 PM
 */

/**
 *
 * @author  Andi
 */
import java.util.*;
import java.rmi.Naming; 
import java.rmi.RemoteException; 
import java.net.MalformedURLException; 
import java.rmi.NotBoundException; 

public class ClientSide {
    private GameConsole       clientConsole;
    private RMI           rmi;
    private ServerInterface  server;
    private ClientInterface  client;

    
    /** Creates a new instance of ClientSide */
    public ClientSide() {
        rmi = new RMI ();
    }
    private void connectTo(String serverName, String clientID){
        server = rmi.getServerService(serverName);
        // Fixed bug....server is not exist....try again.
        if(server == null) {
            System.out.println("ClientSide <GameName>   - game not exist");
            System.exit(0);
        }
        String CID = rmi.registerClient(server, clientID, serverName);
        if (!CID.equals("00")) {
            rmi.bindingClientService(CID+"_on_"+serverName);
            client = rmi.getMyClient(CID+"_on_"+serverName);
            
            //Create Console thread to receive command.
            
            clientConsole = new GameConsole("client", CID, server, client, serverName);
            
            
            clientConsole.start(rmi);
        }
        else {
            System.exit(0);
        }
    }
    

    public static void main(String[] args) {
        ClientSide c = new ClientSide();
        if(args.length == 2)
            c.connectTo(args[0], args[1]);
        else{
            System.out.println("ClientSide <GameName> <ID>");
            System.exit(0);
        }
    }
    
}
