/*
 * GameConsole.java
 *
 * Created on April 10, 2005, 9:12 PM
 */

/**
 *
 * @author  Andi
 */
import java.util.*;
import java.io.*;

public class GameConsole {
    private String CID;
    private String pwd;
    private boolean connected = false;
    private String function ="" ;                   //server or client;
    private ServerInterface serverInterface;
    private ClientInterface clientInterface;
    private RMI rmi;                           // Strange design
    private String connectedServer;
    
    /** Creates a new instance of Client */
    public GameConsole(String function, String CID, ServerInterface serverInterface, 
    ClientInterface clientInterface, String connectedServer) {
        this.function = function;
        this.serverInterface   = serverInterface;
        this.CID = CID;
        this.connectedServer = connectedServer;
        this.clientInterface = clientInterface;
        connected = true;
    }
    
    public GameConsole(String function) {
        this.function = function;
        connected = false;
    }
    
    public void start(RMI rmi) {
        this.rmi = rmi;
        //try {
            //clientInterface = new ClientImpl();
        //} catch(Exception e) {System.out.println(e);}
        boolean exit = false;
        String str = "";
        String command = "";
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer token = new StringTokenizer("");
        //initialize goods
        try {
           serverInterface.getMyGoods(CID, connectedServer);
        }catch(Exception e) {System.out.println(e);}
        
        while (!exit) {

            if(function.equals("client"))
                System.out.print("player "+CID +" %  ");
            else if(function.equals("server"))
                System.out.print("server %  ");

            try {
                str = in.readLine();
            } catch (Exception e) { 
                System.out.println("Error reading input   ");
                System.exit(0);
            }
            //try {
                //clientInterface.ViewMyWealth();
            //} catch (Exception e){System.out.println(e);}
            if(connected == true)
                Action(str, in);                // All commands in connected mode
        }

    }            

    // Connected mode
    public void Action(String str, BufferedReader in){
        StringTokenizer token = new StringTokenizer("");
        String command="";
        try{
            if( str.length() > 0  ){
                token = new StringTokenizer(str);
                command = token.nextToken();
            }
            else {
                command = "enter";
            }
        } catch (Exception e) { 
            System.out.println("Error reading input, Quit !");
            System.exit(0);
        }
        if ( command.equals("exit")) {
            System.exit(0);
        }
        else if ( command.equals("my_wealth")) {
                try {
                    clientInterface.ViewMyWealth();
                } catch(Exception e){System.out.println(e);}
        }
        else if ( command.equals("my_value")) {
            double myValue = 0.0;
            try {
                myValue = clientInterface.getMyValue();
            } catch(Exception e){System.out.println(e);}
            //System.out.println("my value: $"+myValue);
        }

        else if ( command.equals("my_bid_list")) {
                try {
                    clientInterface.showBidList();
                } catch(Exception e){System.out.println(e);}
        }
        else if ( command.equals("my_sell_list")) {
                try {
                    clientInterface.showSellList();
                } catch(Exception e){System.out.println(e);}
        }
        else if ( command.equals("sell_item")) {
            if (token.countTokens() == 6) {
                String itemName = token.nextToken();
                String amount = token.nextToken();
                String description = token.nextToken();
                String startPrice = token.nextToken();
                String reservePrice = token.nextToken();
                String closeTime = token.nextToken();
                if (this.checkItemName(itemName)) {
                try {
                    
                    serverInterface.addSellItem (itemName, amount, description, startPrice, reservePrice, closeTime, CID, connectedServer);
                } catch(Exception e){System.out.println(e);}
                }
                else
                    System.out.println("the item name is invalid!");
            }
            else {
                if (token.countTokens() == 5) {
                    String itemName = token.nextToken();
                    String amount = token.nextToken();
                    String description = token.nextToken();
                    String startPrice = token.nextToken();
                    String closeTime = token.nextToken();
                    if (this.checkItemName(itemName)){
                    try {
                        serverInterface.addSellItem (itemName, amount, description, startPrice, "0", closeTime, CID, connectedServer);
                    } catch(Exception e){System.out.println(e);}
                    }
                    else
                        System.out.println("the item name is invalid!");
                }
                else {
                    System.out.println("sell_item <ItemName> <Amount> <Description> <StartingPrice> [<ReservePrice>] <ClosingTime>");
                }
            }
        }
        
        else if ( command.equals("help")) {
            if (token.countTokens() <= 1) 
                help(token);
            else
                System.out.println("help [<command>]");
        }
        
        else if ( command.equals("bid_item")) {
            if (token.countTokens() == 2) {
                try {
                    String trID = token.nextToken();
                    String bidValue = token.nextToken();
                    serverInterface.addBid (trID, CID, bidValue, connectedServer);
                } catch(Exception e){System.out.println(e);}
            }
            else {
                System.out.println("bid_item <itemID> <BidValue>");
            }
        }
        else if ( command.equals("proxy_bid_item")) {
            if (token.countTokens() == 3) {
                try {
                    String trID = token.nextToken();
                    String bidValue = token.nextToken();
                    String highest = token.nextToken();
                    serverInterface.addProxyBid (trID, CID, bidValue, highest, connectedServer);
                } catch(Exception e){System.out.println(e);}
            }
            else {
                System.out.println("proxy_bid_item <itemID> <BidValue> <Highest Acceptable Price>");
            }
        }
        else if ( command.equals("sell_list")) {
                try {
                    serverInterface.viewItemList(CID, connectedServer);
                } catch(Exception e){System.out.println(e);}
        }
        else if ( command.equals("bid_history")) {
            if (token.countTokens() == 1) {
                try {
                    String trID = token.nextToken();
                    serverInterface.viewBidList (trID, CID, connectedServer);
                } catch(Exception e){System.out.println(e);}
            }
            else {
                System.out.println("bid_history <itemID>");
            }
        }
        else if ( command.equals("closed_list")) {
                try {
                    serverInterface.viewClosedItem(CID, connectedServer);
                } catch(Exception e){System.out.println(e);}
        }
        else {
            if( ! command.equals("enter")){
                System.out.println("'"+command+"' is not recognized."); 
                System.out.println("Type help for detail commands");
            }
        }
    }
    public boolean checkItemName(String name) {
        Hashtable<String, String> namePool = new Hashtable<String, String>();
        namePool.put("1", "TootsieRolls");
        namePool.put("2", "AssortedChocolates");
        namePool.put("3", "CaramelPop");
        namePool.put("4", "CappuccinoChocolate");
        namePool.put("5", "HersheysKisses");
        namePool.put("6", "JordanAlmonds");
        namePool.put("7", "Cashews");
        namePool.put("8", "KitKatBar");
        namePool.put("9", "AnimalCrackers");
        namePool.put("10", "VanillaButtercreams");
        if (namePool.containsValue(name))
            return true;
        else
            return false;
    }
    
    public void help (StringTokenizer token ) {
        if (token.countTokens() == 1) {
            String option = token.nextToken();
            if (option.equals("my_wealth")) {
                System.out.println("-- my_wealth --");
                System.out.println("List the wealth.");
            }
            else if (option.equals("my_value")) {
                System.out.println("-- my_value --");
                System.out.println("Get the personal value of wealth.");
            }
            else if (option.equals("exit")) {
                System.out.println("-- exit --");
                System.out.println("Causes Client to terminate.");
            }
            else if (option.equals("my_bid_list")) {
                System.out.println("-- my_bid_list --");
                System.out.println("List the item you ever bid.");
            }
            else if (option.equals("my_sell_list")) {
                System.out.println("-- my_sell_list --");
                System.out.println("List the item you ever sell.");
            }
            else if (option.equals("sell_item")) {
                System.out.println("-- sell_item <ItemName> <Amount> <Description> <StartingPrice> [<ReservePrice>] <ClosingTime> --");
                System.out.println("Sell the named item.");
            }
            else if (option.equals("bid_item")) {
                System.out.println("-- bid_item <TransactionID> <BidValue> --");
                System.out.println("Enter a bid of named item.");
            } 
            else if (option.equals("proxy_bid_item")) {
                System.out.println("-- proxy_bid_item <TransactionID> <BidValue> <Highest Acceptable Price> --");
                System.out.println("Enter a proxy bid of named item.");
            }
            else if (option.equals("sell_list")) {
                System.out.println("-- sell_list --");
                System.out.println("View the items for sale.");
            }  
            else if (option.equals("help")) {
                System.out.println("-- help [<command>] --");
                System.out.println("Gets help of the commands.");
            }
            else if (option.equals("bid_history")) {
                System.out.println("-- bid_history <TransactionID> --");
                System.out.println("View the list of bids of named item.");
            }  
            else if (option.equals("closed_list")) {
                System.out.println("-- closed_list --");
                System.out.println("View the list of closed auctions.");
            }  
            else
                System.out.println("This command does not exist.");
        }
        else {
            System.out.println("-- my_wealth --");
            System.out.println("List the wealth.");
            System.out.println(" ");
            System.out.println("--  my_value  --");
            System.out.println("Get the personal value of wealth.");
            System.out.println(" ");
            System.out.println("--  exit  --");
            System.out.println("Causes Client to terminate.");
            System.out.println(" ");
            System.out.println("-- my_bid_list --");
            System.out.println("List the item you ever bid.");
            System.out.println(" ");
            System.out.println("--  my_sell_list --");
            System.out.println("List the item you ever sell.");
            System.out.println(" ");
            System.out.println("-- sell_item <ItemName> <Amount> <Description> <StartingPrice> [<ReservePrice>] <ClosingTime> --");
            System.out.println("Sell the named item.");
            System.out.println(" ");
            System.out.println("--  bid_item <TransactionID> <BidValue>  --");
            System.out.println("Enter a bid of named item.");
            System.out.println(" ");
            System.out.println("--  proxy_bid_item <TransactionID> <BidValue> <Highest Acceptable Price>  --");
            System.out.println("Enter a proxy bid of named item.");
            System.out.println(" ");
            System.out.println("--  sell_list  --");
            System.out.println("View the items for sale.");
            System.out.println(" ");
            System.out.println("--  closed_list  --");
            System.out.println("View the list of closed auctions.");
            System.out.println(" ");
            System.out.println("--  bid_history <TransactionID>  --");
            System.out.println("View the list of bids of named item.");
            System.out.println("--  help [<command>]  --");
            System.out.println("Gets help of the commands.");
        }
    }
    
}
