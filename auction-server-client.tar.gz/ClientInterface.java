/*
 * ClientInterface.java
 *
 * Created on April 10, 2005, 12:07 AM
 */

/**
 *
 * @author  Andi
 */
import java.util.*;

public interface ClientInterface extends java.rmi.Remote {
    public void ViewMyWealth()throws java.rmi.RemoteException;
    
    public void addSellList(String trID, String itemName, String amount, String itemDescription,
    String startPrice, String reservePrice, String closingTime)throws java.rmi.RemoteException;
    
    public double getAmount(String itemName)throws java.rmi.RemoteException;
    
    public double getMoney()throws java.rmi.RemoteException;
    
    public void addBidList(String trID, String itemName, String amount, String price, String bidTime)throws java.rmi.RemoteException;
    
    public void showSellList()throws java.rmi.RemoteException;
    
    public void showBidList()throws java.rmi.RemoteException;
    
    public void printMessage(String str)throws java.rmi.RemoteException;
    
    public void terminateSystem () throws java.rmi.RemoteException;
    
    public void initialWealth(Hashtable wealth)throws java.rmi.RemoteException;
    
    public void sellTransaction(String trID, String itemName, String sellAmount, String sellPrice)throws java.rmi.RemoteException;
    
    public void bidTransaction(String trID, String itemName, String amount, String payment)throws java.rmi.RemoteException;
    
    public void failSell(String trID)throws java.rmi.RemoteException;
    
    public void failBid(String trID)throws java.rmi.RemoteException;
    
    public boolean checkAmount(String itemName, String amount)throws java.rmi.RemoteException;
    
    public boolean checkMoney(String price)throws java.rmi.RemoteException;
    
    public double getMyValue()throws java.rmi.RemoteException;
    
    
}
