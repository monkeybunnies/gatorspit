/*
 * RMI.java
 * Bind and look up server and clients services  
 *
 * Author Shuo_Li
 * Student ID : 9902-9980
 * Project 3, Operating System COP5615 Spring 2005, Dr. Nemo 
 */
import java.util.*;
import java.rmi.Naming; 
import java.rmi.RemoteException; 
import java.net.MalformedURLException; 
import java.rmi.NotBoundException; 

public class RMI {
    private String        RMI_Port ;          
    private ServerInterface  server;
    
    /** Creates a new instance of Server */
    public RMI() {
        // Get the RMI Registry port !!!!
        RMI_Port = "5397";
    }

    public ServerInterface getServerService(String serverName){
        ServerInterface s = null;
        try { 
            s = (ServerInterface) Naming.lookup("rmi://localhost:"+ RMI_Port+"/sli_"+ serverName); 
        } 
        catch (MalformedURLException murle) { System.out.println("MalformedURLException"); 
        } 
        catch (RemoteException re) { System.out.println("RemoteException"); 
        } 
        catch (NotBoundException nbe) { 
            System.out.println("Server "+ serverName + " doesn't exist"); 
        } 
        return s;
    }
    
    public String registerClient(ServerInterface server, String CID, String serverName){
        try{
            CID = server.registerNewClient(CID, serverName);
        }catch (java.rmi.RemoteException e)
        {
            System.out.println("Remote Exception on client, recheck and try again");
            System.exit(0);
        }
        return CID;
    }
    
    
    public void bindingClientService(String clientIDRef){
        try {
           ClientInterface c = new ClientImpl();
           Naming.rebind("rmi://localhost:"+ RMI_Port+"/sli_"+clientIDRef, c);
        } catch (Exception e) {
           System.out.println("Trouble when register to RMI: ");
        }
    }    
    
    /* 
    // Get client from RMI 
     */
    public ClientInterface getMyClient (String clientIDRef){
        ClientInterface  c = null;
        try { 
            c = (ClientInterface) Naming.lookup("rmi://localhost:"+ RMI_Port+"/sli_"+clientIDRef); 
            } 
            catch (MalformedURLException murle) { 
                System.out.println("MalformedURLException"); 
            } 
            catch (RemoteException re) { 
                System.out.println("RemoteException"); 
            } 
            catch (NotBoundException nbe) { 
                System.out.println("NotBoundException"); 
            } 
        return c;
    }

}