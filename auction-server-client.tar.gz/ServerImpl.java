/*
 * ServerImpl.java
 *
 * Created on April 10, 2005, 12:29 AM
 */

/**
 *
 * @author  Andi
 */
import java.util.*;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.Naming; 
import java.rmi.RemoteException; 
import java.net.MalformedURLException; 
import java.rmi.NotBoundException; 

public class ServerImpl extends java.rmi.server.UnicastRemoteObject implements ServerInterface {
    private SellDataStructure sell;
    private BidDataStructure bid;
    private Inventory inventory;
    //private HashMap<String, String> ClientTable = new HashMap<String, String> ();
    private RMI rmi;
    /** Creates a new instance of ServerImpl */
    public ServerImpl(RMI rmi, SellDataStructure sell, BidDataStructure bid) throws java.rmi.RemoteException {
        //sell = new SellDataStructure();
        //bid = new BidDataStructure(sell);
        inventory = new Inventory();
        this.rmi = rmi;
        this.sell = sell;
        this.bid = bid;
    }
    
    public String registerNewClient(String CID, String serverName) throws java.rmi.RemoteException {
        RegisterClient registration = new RegisterClient(serverName);
        String result = registration.registerNewClient(CID);
        return result;
    }
    
    public void getMyGoods(String clientID, String serverName) throws java.rmi.RemoteException {
        ClientInterface c = rmi.getMyClient(clientID+"_on_"+serverName);
        try{
            c.initialWealth((Hashtable) inventory.GetMyGoods());
        }
        catch (java.rmi.RemoteException e){System.out.println("Remote Exception :"+e);
        }
        //Hashtable<String, Hashtable> myGoods = new Hashtable<String, Hashtable> ();
        //myGoods = inventory.GetMyGoods();
        //return myGoods;
        
    }
    
    public void addSellItem(String name, String amount, String desc, String startPrice, 
    String reservePrice, String closeTime, String CID, String connectedServer) throws java.rmi.RemoteException {
        //ServerAddItem implements Runnable, do checking, invoking client side services
        
        ServerAddItem addItem = new ServerAddItem(name, amount, desc, startPrice, reservePrice, closeTime, CID, connectedServer, sell, rmi);
        Thread t = new Thread(addItem);
        t.start();
        
    }
    
    public void addBid(String trID, String CID, String bidValue, String connectedServer) throws java.rmi.RemoteException {
        
        ServerAddBid addBid = new ServerAddBid(trID, CID, bidValue, bid, connectedServer, rmi);
        Thread t = new Thread(addBid);
        t.start();
    }
    
    public void addProxyBid(String trID, String CID, String bidValue, String highest, String connectedServer)
    throws java.rmi.RemoteException {
        ClientInterface c = rmi.getMyClient(CID+"_on_"+connectedServer);
        double startprice = Double.valueOf(bidValue).doubleValue();
        double endprice = Double.valueOf(highest).doubleValue();
        if (startprice < endprice) {
            ServerProx proxy = new ServerProx(trID, CID, bidValue, highest, bid, c);
            Thread t = new Thread(proxy);
            t.start();
        }
        else
            try {
                c.printMessage("The initial value should be higher than the highest acceptable value.");
            } catch(Exception e) {System.out.println(e);}
    }
    
    public void viewItemList(String CID, String connectedserver) throws java.rmi.RemoteException {
        ServerViewItem itemlist = new ServerViewItem(sell, bid, CID, connectedserver, rmi);
        Thread t = new Thread(itemlist);
        //for(;;) {
            t.start();
            //try {
                //t.sleep(5000);
            //} catch (Exception e) {System.out.println(e);}
        //}
    }
    
    public void viewBidList(String trID, String CID, String connectedserver) throws java.rmi.RemoteException {
        ServerViewBid bidlist = new ServerViewBid(trID, bid, CID, connectedserver, rmi);
        Thread t = new Thread(bidlist);
        t.start();
    }
    
    public void viewClosedItem(String CID, String connectedserver) throws java.rmi.RemoteException {
        ServerGetClosedItem closeditem = new ServerGetClosedItem(sell, bid, CID, connectedserver, rmi);
        Thread t = new Thread(closeditem);
        t.start();
    }
}
