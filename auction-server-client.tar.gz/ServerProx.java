import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.concurrent.*;


class ServerProx extends Thread implements Runnable {
    String trID;
    String bID;
    String initialprice;
    String endPrice;
    BidDataStructure proxbid;
    //String serverName;
    //RMI rmi;
    ClientInterface c;
    SellDataStructure sell;
    
    //CountDownLatch cnt;

    /** Creates a new instance of ServerProx */
    public ServerProx(String tranID, String bidderID, String initialprice, String endprice,
    BidDataStructure bidview, ClientInterface c) {
        trID=tranID;
        bID=bidderID;
        endPrice=endprice;
        //cnt=totalcounter;
        proxbid=bidview;
        //this.serverName = serverName;
        //this.rmi = rmi;
        this.c = c;
        this.initialprice = initialprice;
        this.sell = new SellDataStructure();
    }
    public void run(){
        boolean success=false;
        //ClientInterface c = rmi.getMyClient(bID+"_on_"+serverName);
        
        Calendar cal = new GregorianCalendar();
        int hour24 = cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);
        double bidTime = hour24 + .01*minute;
        String bTime = Double.toString(bidTime);
        
        String itemName = sell.getItemName(trID);
        String amount = sell.getAmount(trID);
        
        if(proxbid.checkProx((String)trID)) {
            try {
                c.printMessage("Already exist proxy bid for this item");
            }catch(Exception e) {System.out.println(e);}
        }
        else {
            success = proxbid.addBidList((String)trID, (String)bID, (String)initialprice, (String)bTime);
            if (success) {
                try {
                    c.addBidList(trID, itemName, amount, initialprice, bTime);
                    success = c.checkMoney(endPrice);
                } catch (Exception e) {System.out.println(e);}
                if (success) {
                    success = proxbid.proxyBidValue((String)trID, (String)bID, (String)endPrice);
                    if (success) {
                        try {
                            c.printMessage("Setup proxy bid for item: "+trID+" SUCCESSFULLY!");
                        } catch(Exception e) {System.out.println(e);}
                    }
                    else {
                        try {
                            c.printMessage("Setup proxy bid for item: "+trID+" FAILED!");
                        } catch(Exception e) {System.out.println(e);}
                    }
                }
                else {
                    try {
                        c.printMessage("Setup proxy bid for item: "+trID+" FAILED! No enough Money");
                    } catch(Exception e) {System.out.println(e);}
                }
            }
            
            else {
                try {
                    c.printMessage("Setup proxy bid for item: "+trID+" FAILED! ");
                } catch(Exception e) {System.out.println(e);}
            }
        }
    }
    
}

