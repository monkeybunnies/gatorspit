/*
 * ServerGetClosedItem.java
 *
 * Created on April 10, 2005, 3:35 PM
 */

/**
 *
 * @author  Andi
 */


import java.util.*;
import java.util.HashMap;

public class ServerGetClosedItem extends Thread implements Runnable{
    //private BidDataStructure bid;
    private SellDataStructure sell;
    private Calendar cal;
    private static Hashtable<String, HashMap> ClosedItem = new Hashtable<String, HashMap>();
    private RegisterClient getClient;
    private String serverName;
    private RMI rmi;
    private String CID;
    private BidDataStructure bidList;
    
    /** Creates a new instance of ServerGetClosedItem */
    public ServerGetClosedItem(SellDataStructure sell, BidDataStructure bidlist,String CID, 
    String serverName, RMI rmi)  {
        this.CID = CID;
        this.sell = sell;
        //this.bid = bid;
        cal = new GregorianCalendar();
        getClient = new RegisterClient(serverName);
        this.serverName = serverName;
        this.rmi = rmi;
        this.bidList=bidlist;
    }
    /**
    public synchronized HashMap getClosedItem() {
        ClosedItem.putAll((HashMap) sell.getClosedItem());
        Hashtable<String, HashMap> closed = new Hashtable<String, HashMap> ();
        closed.putAll((HashMap) sell.getClosedItem());
        if (!closed.isEmpty()) {
            for (Enumeration e = closed.keys() ; e.hasMoreElements() ;) {
                String key = (String) e.nextElement();
                String sID = (String) closed.get(key).get("SellerID");
                String bID = (String) closed.get(key).get("BidderID");
                String itemName = (String) closed.get(key).get("itemName");
                String amount = (String) closed.get(key).get("Amount");
                String value = (String) closed.get(key).get("Value");
                String status = (String) closed.get(key).get("Status");
                ClientInterface s = rmi.getMyClient(sID+"_on_"+serverName);
                ClientInterface b = rmi.getMyClient(bID+"_on_"+serverName);
                boolean canSell = false;
                boolean canBuy = false;
                if (status.equals("sold")) {
                    // If item sold, invoke sellTransaction in seller
                    // invoke bidTransaction in bidder
                    try {
                        canSell = s.checkAmount(itemName, amount);
                        canBuy = b.checkMoney(value);
                    
                    } catch (Exception ex) {System.out.println(ex);}
                    if (canSell && canBuy) {
                        try {
                            s.sellTransaction(key, itemName, amount, value);
                            s.printMessage("Sell Item "+itemName+" SUCCESSFULLY!");
                            b.bidTransaction(key, itemName, amount, value);
                            b.printMessage("Buy Item "+itemName+" SUCCESSFULLY!");
                        } catch (Exception ex) {System.out.println(ex);}
                    }
                    else {
                        try {
                            s.failSell(key);
                            s.printMessage("Sell Item "+itemName+" FAILED!");
                            b.failBid(key);
                            b.printMessage("Bid Item "+itemName+" FAILED!");
                        } catch (Exception ex) {System.out.println(ex);}
                        ClosedItem.get(key).put("Status", "closed");
                    }
                    
                }
                else {
                    try {
                        s.failSell(key);
                        s.printMessage("Sell Item "+itemName+" FAILED!");
                        b.failBid(key);
                        b.printMessage("Bid Item "+itemName+" FAILED!");
                    } catch (Exception ex) {System.out.println(ex);}
                }
                    
            }
        }
        return (HashMap) sell.getClosedItem();
    }
     */
    
    public void addClosedItem() {
        ClosedItem.putAll((HashMap) sell.getClosedItem());
    }
    
    public void changeStatus(String key) {
        ClosedItem.get(key).put("Status", "closed");
    }
    
    public void run() {
          /* for (Enumeration e = ClosedItem.keys() ; e.hasMoreElements() ;) {
                String key = (String) e.nextElement();
                System.out.println("Transaction ID: "+key);
                System.out.println("Item Name: "+ClosedItem.get(key).get("itemName"));
                System.out.println("Amount: "+ClosedItem.get(key).get("Amount"));
                System.out.println("Seller ID: "+ClosedItem.get(key).get("SellerID"));
                System.out.println("Bidder ID: "+ClosedItem.get(key).get("BidderID"));
                System.out.println("Bid Value: "+ClosedItem.get(key).get("Value"));
                System.out.println("Status: "+ClosedItem.get(key).get("Status"));
                System.out.println("--------------------------------------");
            }*/
        GameOver gameover=new GameOver(sell,bidList);
        HashMap<String,HashMap> showList=new HashMap<String,HashMap>();
        showList=gameover.gameOver();
        Iterator iterator = showList.keySet().iterator();
        HashMap<String,HashMap> closeList=new HashMap<String,HashMap>();
        int i=0;
        if(iterator.hasNext()){
         while (iterator.hasNext()) {
	   String key = (String)iterator.next();
           String flag=key.substring(0,1);
           String itemKey=key.substring(2);
           HashMap<String,String> listContent=new HashMap<String,String>();
           
          listContent=showList.get(key);
           
           //System.out.println("Item's "+itemKey+"flag is:"+flag);
            //Iterator it = itemList.keySet().iterator();
            /*if(!it.hasNext()) System.out.println("No item");
            while(it.hasNext()){
                String ilist=(String)it.next();
                System.out.println("key is:"+ilist);
            }
           */     
           if(flag.equals("C")){
               closeList.put(itemKey,listContent);
               i++;
                
           }
         
         
       
       }
        String[] showShow=new String[i];
        Iterator iterat = closeList.keySet().iterator();
        int j=0;
        
        while (iterat.hasNext()) {
	   String  key1= (String)iterat.next();
           HashMap<String,String> slist=new HashMap<String,String>();
           slist=closeList.get(key1);
           showShow[j]="ItemID:"+key1+",Item Name:"+slist.get("Item Name")+",Description:"+slist.get("Description")+",Sale Price:"+slist.get("Sale Price")+",Buyer ID:"+slist.get("Buyer ID")+",Seller ID:"+slist.get("Seller ID");
          
           j++;
           }
        }
        else System.out.println("Empty list!");
}
    
}
