/*driver2 problem:
  max r(t_f)
  system dynamics:
             r' = u,
             u' = v^2/r - mu/(r^2) + T*sin(control)/(m0-|mdot|*t),
             v' = -(u*v)/r + T*cos(control)/(m0-|mdot|*t),
  initial conditions:
             r(t_0) = r0,
             u(t_0)=0,
             v(t_0)=sqrt(mu/r0),
  final conditions:
             u(t_f)=0,
             v(t_f)=sqrt(mu/r(t_f)),
  use penalty approch, we use Lagrange multipliers lamda_1 and lamda_2, 
  and a constant penalty factor p, the cost function at step k is defined as:
  min -r(t_f) + p*(u(t_f))^2 + p*(v(t_f)-sqrt(mu/r(t_f)))^2 + lamda_1_k*u(t_f)
      +lamda_2_k*(v(t_f)-sqrt(mu/r(t_f)))
      at step k+1, update the multipliers by:
              lamda_1_(k+1) = lamda_1_k + 2*p*u(t_f),
              lamda_2_(k+1) = lamda_2_k + 2*p*(v(t_f)-sqrt(mu/r(t_f))).
*/
#include "optcon.h"
void my_f(double *f, double *x, double *u, double time);// evaluate of f(x)
void my_dphi(double *dphi, double *x_f); // evaluate of dF/dx
double my_phi(double *x_f); //evaluate of F
void my_fu(double *fu, double *x, double *u, double time); //evaluate of df/du
void my_fx(double *fx, double *x, double *u, double time); //evaluate of df/dx
double r0 = 149.6e9;
double m0 = 10000;
double mdot = 12.9e0/(24e0*3600e0);
double mu = 1.327330000000000e+20;
double T = .85e0*9.807e0;
double lamda[2];
double p;
int n = 500;
int nx = 3;
int ns = 3;
int nc = 1;
int main(void) {
       double t0, tf;
       double *state0;
       double *state;
       double *control;
       double *a;
       double *b;
       double error, olderr;
       double grad_tol = 1.0e-6;
       int tolFac = 1000;
       int i, x1, x2, x3;
       t0 = 0;
       tf = 193*24*3600;
       p = 10000;
       lamda[0] = 7155756.1019616;
       lamda[1] = -6348152.2785148;
       /*assign working space */
       state0  = (double*) malloc(nx*sizeof(double));
       state   = (double*) malloc((n*ns*nx+nx)*sizeof(double));
       control = (double*) malloc(n*ns*nc*sizeof(double));
       /*initial control*/
       for (i = 0; i < n*ns*nc; i ++) {
           control[i] = 0;
       }
       /*initial state0*/
       state0[0] = r0;
       state0[1] = 0;
       state0[2] = sqrt(mu/r0);
       olderr = 1.e50;
       /*define the locations of final state variables*/
       x1 = n*ns*nx;
       x2 = n*ns*nx + 1;
       x3 = n*ns*nx + 2;
       /* call optcon , maximum iterations 10000 */
       for (i = 0; i < 10000; i ++) {
           optcon(grad_tol, n, nx, nc, ns, t0, tf, control, state0, 
                  state, a, b, my_phi, my_dphi, my_f, my_fx, my_fu);
           error = fabs(state[x2]) + fabs(state[x3]-sqrt(mu/state[x1]));
           printf ("error = %.4e\n", error);
           if (error >= olderr) goto Exit;
           grad_tol = tolFac*error;
           olderr = error;
           lamda[0] = lamda[0] + 2*p*state[x2];
           lamda[1] = lamda[1] + 2*p*(state[x3]-sqrt(mu/state[x1]));
       /* free the memory */
       }
       Exit: ;
       free (state0);
       free (state);
       free (control);
}

void my_f(double *f, double *x, double *u, double time) 
{
     double  d;
     extern double m0;
     extern double mdot;
     extern double mu;
     extern double T;
     d = m0 - mdot*time;
     f[0] = x[1];
     f[1] = (x[2]*x[2])/x[0] - mu/(x[0]*x[0]) + T*(sin(*u)/d);
     f[2] = -(x[1]*x[2])/x[0] + T*(cos(*u)/d);
     return;
}

void my_dphi(double *dphi, double *x_f) 
{
     double s;
     extern double mu;
     extern double lamda[2];
     extern double p;
     s = x_f[2] - sqrt(mu/x_f[0]);
     dphi[0] = -1e+0 + (p*s + .5*lamda[1])*sqrt(mu/pow(x_f[0], 3));
     dphi[1] = 2*p*x_f[1] + lamda[0];
     dphi[2] = 2*p*s + lamda[1];
     return;
}

double my_phi(double *x_f)
{
     double s, tcost;
     extern double lamda[2];
     extern double p;
     extern double mu;
     s = x_f[2] - sqrt(mu/x_f[0]);
     tcost = -x_f[0] + p*(x_f[1]*x_f[1] + s*s) + lamda[0]*x_f[1] + lamda[1]*s;
     return tcost;
}

void my_fu(double *fu, double *x, double *u, double time)
{
     double d;
     extern double m0;
     extern double mdot;
     extern double T;
     d = m0 - mdot*time;
     fu[0] = 0;
     fu[1] = T*(cos(*u)/d);
     fu[2] = -T*(sin(*u)/d);
     return;
     /*delete after compile*/
     double a;
     a = x[0];
}

void my_fx(double *fx, double *x, double *u, double time) 
{
     extern double mu;
     fx[0] = 0;
     fx[3] = (2*mu/x[0] - x[2]*x[2])/(x[0]*x[0]);
     fx[6] = x[1]*x[2]/(x[0]*x[0]);
     
     fx[1] = 1;
     fx[4] = 0;
     fx[7] = -x[2]/x[0];
     
     fx[2] = 0;
     fx[5] = 2*x[2]/x[0];
     fx[8] = -x[1]/x[0];
     return;
     /* delete after compile */
     double a, b;
     a = *u;
     b = time;
}
